import React from 'react';

interface CrestLogoProps {
  className?: string;
  variant?: 'plum' | 'light';
}

export const CrestLogo: React.FC<CrestLogoProps> = ({
  className = 'w-9 h-9',
  variant = 'plum',
}) => {
  const strokeColor = variant === 'plum' ? '#4A2538' : '#FFFFFF';
  const accentColor = '#C88A55';

  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* Outer Diamond / Arch Crest */}
      <path
        d="M24 3L43 17V31L24 45L5 31V17L24 3Z"
        stroke={strokeColor}
        strokeWidth="1.75"
        strokeLinejoin="round"
      />
      {/* Inner Geometric Arch Frame */}
      <path
        d="M24 7.5L38.5 18.5V29.5L24 40.5L9.5 29.5V18.5L24 7.5Z"
        stroke={accentColor}
        strokeWidth="1"
        strokeLinejoin="round"
        opacity="0.85"
      />
      {/* Crisp Geometric "W" Monogram */}
      <path
        d="M14.5 18.5L19.2 30.5L24 21L28.8 30.5L33.5 18.5"
        stroke={strokeColor}
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Top Apex Accent */}
      <circle cx="24" cy="12.5" r="1.4" fill={accentColor} />
    </svg>
  );
};

interface OfficialStampProps {
  sealLabel: string;
  regNo: string;
}

export const OfficialStamp: React.FC<OfficialStampProps> = ({ sealLabel, regNo }) => {
  return (
    <div className="relative inline-flex items-center justify-center w-28 h-28 select-none">
      <svg
        viewBox="0 0 120 120"
        className="w-full h-full text-[#4A2538]"
        aria-hidden="true"
      >
        <circle
          cx="60"
          cy="60"
          r="54"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeDasharray="3 2"
          opacity="0.85"
        />
        <circle
          cx="60"
          cy="60"
          r="48"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.2"
          opacity="0.9"
        />
        <circle
          cx="60"
          cy="60"
          r="31"
          fill="none"
          stroke="#C88A55"
          strokeWidth="1"
          opacity="0.9"
        />
        <path
          id="topArc"
          d="M 18,60 A 42,42 0 1,1 102,60"
          fill="none"
        />
        <text
          fill="currentColor"
          fontSize="6.6"
          fontWeight="700"
          letterSpacing="1.4"
        >
          <textPath href="#topArc" startOffset="50%" textAnchor="middle">
            {sealLabel}
          </textPath>
        </text>
        <path
          id="bottomArc"
          d="M 102,62 A 42,42 0 1,1 18,62"
          fill="none"
        />
        <text
          fill="#4F5D52"
          fontSize="6.2"
          fontWeight="600"
          letterSpacing="1"
        >
          <textPath href="#bottomArc" startOffset="50%" textAnchor="middle">
            TÉTOUAN · MOROCCO
          </textPath>
        </text>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
        <CrestLogo className="w-7 h-7" variant="plum" />
        <span className="mt-0.5 text-[7px] font-mono font-semibold text-[#4A2538] tracking-wider">
          {regNo}
        </span>
      </div>
    </div>
  );
};
