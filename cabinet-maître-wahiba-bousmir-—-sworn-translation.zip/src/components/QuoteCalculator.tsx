import React, { useRef, useState } from 'react';
import {
  Upload,
  FileText,
  Trash2,
  Minus,
  Plus,
  MessageCircle,
  CheckCircle2,
  Mail,
  Printer,
  RotateCcw,
  AlertCircle,
} from 'lucide-react';
import {
  Currency,
  DeliveryMethod,
  DestinationAuthority,
  DirectionPair,
  DocumentCategory,
  Language,
  OrderReceipt,
  TurnaroundSpeed,
  UploadedFileItem,
} from '../types/translation';
import {
  CATEGORY_BASE_MAD,
  DELIVERY_FEE_MAD,
  EXPRESS_MULTIPLIER,
  TranslationDictionary,
  formatCurrency,
} from '../data/translations';

interface QuoteCalculatorProps {
  lang: Language;
  currency: Currency;
  t: TranslationDictionary;
  category: DocumentCategory;
  setCategory: (c: DocumentCategory) => void;
}

export const QuoteCalculator: React.FC<QuoteCalculatorProps> = ({
  lang,
  currency,
  t,
  category,
  setCategory,
}) => {
  const [direction, setDirection] = useState<DirectionPair>('ar-en');
  const [destination, setDestination] = useState<DestinationAuthority>('usa');
  const [speed, setSpeed] = useState<TurnaroundSpeed>('standard');
  const [pages, setPages] = useState<number>(2);
  const [delivery, setDelivery] = useState<DeliveryMethod>('pickup');
  const [files, setFiles] = useState<UploadedFileItem[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState('');
  const [receipt, setReceipt] = useState<OrderReceipt | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dynamic Pricing Calculation (MAD baseline converted cleanly)
  const basePerPageMad = CATEGORY_BASE_MAD[category];
  const translationMad = basePerPageMad * pages;
  const expressSurchargeMad =
    speed === 'express' ? Math.round(translationMad * (EXPRESS_MULTIPLIER - 1)) : 0;
  const deliveryFeeMad = DELIVERY_FEE_MAD[delivery];
  const totalMad = translationMad + expressSurchargeMad + deliveryFeeMad;

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleFilesAdded = (fileList: FileList | null) => {
    if (!fileList) return;
    const allowedExt = ['pdf', 'jpg', 'jpeg', 'png', 'docx'];
    const nextItems: UploadedFileItem[] = [];

    Array.from(fileList).forEach((file) => {
      const ext = file.name.split('.').pop()?.toLowerCase() || '';
      if (!allowedExt.includes(ext)) return;
      const isImage = file.type.startsWith('image/');
      nextItems.push({
        id: `${file.name}-${file.size}-${Math.random().toString(36).slice(2, 8)}`,
        name: file.name,
        size: file.size,
        type: ext.toUpperCase(),
        previewUrl: isImage ? URL.createObjectURL(file) : undefined,
      });
    });

    if (nextItems.length > 0) {
      setFiles((prev) => [...prev, ...nextItems]);
    }
  };

  const removeFile = (id: string) => {
    setFiles((prev) => {
      const target = prev.find((f) => f.id === id);
      if (target?.previewUrl) {
        URL.revokeObjectURL(target.previewUrl);
      }
      return prev.filter((f) => f.id !== id);
    });
  };

  const buildWhatsAppUrl = (refId?: string) => {
    const dirLabel = t.calculator.directions[direction];
    const catLabel = t.calculator.categories[category].label;
    const destLabel = t.calculator.destinations[destination];
    const speedLabel = `${t.calculator.speeds[speed].label} (${t.calculator.speeds[speed].time})`;
    const delivLabel = t.calculator.deliveries[delivery].label;
    const totalFormatted = formatCurrency(totalMad, currency);
    const fileNames = files.length > 0 ? files.map((f) => f.name).join(', ') : 'To be sent in chat';

    const lines =
      lang === 'ar'
        ? [
            `السلام عليكم أستاذة وهيبة بوسمير، أود طلب ترجمة محلفة:`,
            refId ? `• المرجع: ${refId}` : null,
            `• الاتجاه: ${dirLabel}`,
            `• نوع الوثيقة: ${catLabel}`,
            `• الجهة المستقبلة: ${destLabel}`,
            `• عدد الصفحات: ${pages}`,
            `• السرعة: ${speedLabel}`,
            `• التسليم: ${delivLabel}`,
            `• الملفات: ${fileNames}`,
            `• التكلفة التقديرية: ${totalFormatted}`,
            clientName ? `• الاسم: ${clientName}` : null,
            clientPhone ? `• الهاتف: ${clientPhone}` : null,
            clientEmail ? `• البريد: ${clientEmail}` : null,
            notes ? `• ملاحظات: ${notes}` : null,
          ]
        : lang === 'fr'
        ? [
            `Bonjour Maître Wahiba Bousmir, je souhaite commander une traduction assermentée :`,
            refId ? `• Référence : ${refId}` : null,
            `• Sens : ${dirLabel}`,
            `• Catégorie : ${catLabel}`,
            `• Autorité destinataire : ${destLabel}`,
            `• Nombre de pages : ${pages}`,
            `• Délai : ${speedLabel}`,
            `• Remise / Livraison : ${delivLabel}`,
            `• Fichiers : ${fileNames}`,
            `• Total estimé : ${totalFormatted}`,
            clientName ? `• Nom : ${clientName}` : null,
            clientPhone ? `• Téléphone : ${clientPhone}` : null,
            clientEmail ? `• E-mail : ${clientEmail}` : null,
            notes ? `• Notes : ${notes}` : null,
          ]
        : [
            `Hello Maître Wahiba Bousmir, I would like to order a sworn translation:`,
            refId ? `• Reference: ${refId}` : null,
            `• Direction: ${dirLabel}`,
            `• Category: ${catLabel}`,
            `• Destination Authority: ${destLabel}`,
            `• Pages: ${pages}`,
            `• Turnaround: ${speedLabel}`,
            `• Delivery: ${delivLabel}`,
            `• Files: ${fileNames}`,
            `• Estimated Total: ${totalFormatted}`,
            clientName ? `• Name: ${clientName}` : null,
            clientPhone ? `• Phone: ${clientPhone}` : null,
            clientEmail ? `• Email: ${clientEmail}` : null,
            notes ? `• Notes: ${notes}` : null,
          ];

    const message = encodeURIComponent(lines.filter(Boolean).join('\n'));
    return `https://wa.me/212690129797?text=${message}`;
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clientEmail.trim());
    if (!clientName.trim() || !emailValid || clientPhone.trim().length < 6) {
      setFormError(t.calculator.validationError);
      return;
    }
    setFormError('');

    const referenceId = `WB-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setReceipt({
      referenceId,
      clientName: clientName.trim(),
      clientEmail: clientEmail.trim(),
      clientPhone: clientPhone.trim(),
      direction,
      category,
      destination,
      pages,
      turnaround: speed,
      delivery,
      notes: notes.trim(),
      files: files.map((f) => f.name),
      totalFormatted: formatCurrency(totalMad, currency),
      currency,
      createdAt: new Date().toLocaleString(),
    });
  };

  const buildMailtoUrl = (rec: OrderReceipt) => {
    const subject = encodeURIComponent(`Sworn Translation Order ${rec.referenceId} — ${rec.clientName}`);
    const body = encodeURIComponent(
      [
        `Order Reference: ${rec.referenceId}`,
        `Client: ${rec.clientName}`,
        `Email: ${rec.clientEmail}`,
        `Phone / WhatsApp: ${rec.clientPhone}`,
        `Direction: ${t.calculator.directions[rec.direction]}`,
        `Category: ${t.calculator.categories[rec.category].label}`,
        `Destination: ${t.calculator.destinations[rec.destination]}`,
        `Pages: ${rec.pages}`,
        `Turnaround: ${t.calculator.speeds[rec.turnaround].label}`,
        `Delivery: ${t.calculator.deliveries[rec.delivery].label}`,
        `Estimated Total: ${rec.totalFormatted}`,
        rec.files.length > 0 ? `Attached File Names: ${rec.files.join(', ')}` : '',
        rec.notes ? `Notes: ${rec.notes}` : '',
      ]
        .filter(Boolean)
        .join('\n')
    );
    return `mailto:wbousmir@gmail.com?subject=${subject}&body=${body}`;
  };

  return (
    <section id="calculator" className="py-14 lg:py-20 bg-white border-b border-[#E8E3DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="max-w-3xl mb-10">
          <p className="text-xs font-semibold tracking-wide text-[#4F5D52] mb-2">
            {t.calculator.sectionKicker}
          </p>
          <h2
            className="font-serif-editorial text-3xl sm:text-4xl font-bold text-[#4A2538] tracking-tight mb-3"
            style={{ textWrap: 'balance' }}
          >
            {t.calculator.sectionTitle}
          </h2>
          <p className="text-base text-[#5C5559] leading-relaxed">
            {t.calculator.sectionSubtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left 7 Columns: Configuration Form */}
          <div className="lg:col-span-7 space-y-8 bg-[#F9F8F6] border border-[#E5DFD7] rounded-xl p-5 sm:p-8">
            {/* 1. Direction */}
            <div>
              <label className="block text-sm font-semibold text-[#4A2538] mb-3">
                {t.calculator.stepDirection}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(['ar-en', 'en-ar'] as DirectionPair[]).map((dir) => (
                  <button
                    key={dir}
                    type="button"
                    onClick={() => setDirection(dir)}
                    className={`px-4 py-3 text-sm font-semibold rounded-lg border text-start transition-colors cursor-pointer ${
                      direction === dir
                        ? 'bg-[#4A2538] text-white border-[#4A2538]'
                        : 'bg-white text-[#1E1A1D] border-[#DDD5CA] hover:border-[#4A2538]'
                    }`}
                  >
                    {t.calculator.directions[dir]}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs text-[#5C5559]">{t.calculator.partnerHint}</p>
            </div>

            {/* 2. Document Category */}
            <div>
              <label className="block text-sm font-semibold text-[#4A2538] mb-3">
                {t.calculator.stepCategory}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(Object.keys(t.calculator.categories) as DocumentCategory[]).map((catKey) => {
                  const cat = t.calculator.categories[catKey];
                  const active = category === catKey;
                  return (
                    <button
                      key={catKey}
                      type="button"
                      onClick={() => setCategory(catKey)}
                      className={`p-3.5 rounded-lg border text-start transition-colors cursor-pointer flex flex-col justify-between ${
                        active
                          ? 'bg-white border-[#4A2538] ring-1 ring-[#4A2538]'
                          : 'bg-white/80 border-[#DDD5CA] hover:border-[#4A2538]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-sm font-semibold text-[#1E1A1D]">
                          {cat.label}
                        </span>
                        <span className="text-xs font-mono font-semibold text-[#4F5D52] tabular-nums shrink-0">
                          {formatCurrency(CATEGORY_BASE_MAD[catKey], currency)}
                        </span>
                      </div>
                      <span className="text-xs text-[#5C5559] leading-snug">
                        {cat.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Destination Country / Authority & 4. Turnaround Speed */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label
                  htmlFor="destination-select"
                  className="block text-sm font-semibold text-[#4A2538] mb-2.5"
                >
                  {t.calculator.stepDestination}
                </label>
                <select
                  id="destination-select"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value as DestinationAuthority)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DDD5CA] rounded-lg text-[#1E1A1D] focus:outline-none focus:border-[#4A2538]"
                >
                  {(Object.keys(t.calculator.destinations) as DestinationAuthority[]).map(
                    (destKey) => (
                      <option key={destKey} value={destKey}>
                        {t.calculator.destinations[destKey]}
                      </option>
                    )
                  )}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#4A2538] mb-2.5">
                  {t.calculator.stepSpeed}
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  {(['standard', 'express'] as TurnaroundSpeed[]).map((sp) => (
                    <button
                      key={sp}
                      type="button"
                      onClick={() => setSpeed(sp)}
                      className={`px-3 py-2 rounded-lg border text-start transition-colors cursor-pointer ${
                        speed === sp
                          ? 'bg-[#4A2538] text-white border-[#4A2538]'
                          : 'bg-white text-[#1E1A1D] border-[#DDD5CA] hover:border-[#4A2538]'
                      }`}
                    >
                      <div className="text-xs font-semibold">
                        {t.calculator.speeds[sp].label}
                      </div>
                      <div
                        className={`text-[11px] mt-0.5 ${
                          speed === sp ? 'text-white/80' : 'text-[#5C5559]'
                        }`}
                      >
                        {t.calculator.speeds[sp].time}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* 5. Page Count */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-[#E5DFD7]">
              <div>
                <label
                  htmlFor="page-count-input"
                  className="block text-sm font-semibold text-[#4A2538]"
                >
                  {t.calculator.stepPages}
                </label>
                <span className="text-xs text-[#5C5559]">
                  {formatCurrency(basePerPageMad, currency)} / {t.calculator.pagesUnit}
                </span>
              </div>

              <div className="inline-flex items-center bg-white border border-[#DDD5CA] rounded-lg">
                <button
                  type="button"
                  onClick={() => setPages((p) => Math.max(1, p - 1))}
                  aria-label="Decrease pages"
                  className="w-10 h-10 inline-flex items-center justify-center text-[#4A2538] hover:bg-[#F9F8F6] rounded-s-lg cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  id="page-count-input"
                  type="number"
                  min={1}
                  max={200}
                  value={pages}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setPages(Number.isNaN(val) ? 1 : Math.min(200, Math.max(1, val)));
                  }}
                  className="w-14 text-center text-sm font-mono font-semibold text-[#1E1A1D] tabular-nums focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setPages((p) => Math.min(200, p + 1))}
                  aria-label="Increase pages"
                  className="w-10 h-10 inline-flex items-center justify-center text-[#4A2538] hover:bg-[#F9F8F6] rounded-e-lg cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* 6. File Upload Dropzone */}
            <div>
              <label className="block text-sm font-semibold text-[#4A2538] mb-2.5">
                {t.calculator.stepUpload}
              </label>

              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  handleFilesAdded(e.dataTransfer.files);
                }}
                onClick={() => fileInputRef.current?.click()}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    fileInputRef.current?.click();
                  }
                }}
                className={`border-2 border-dashed rounded-lg p-5 text-center transition-colors cursor-pointer ${
                  isDragging
                    ? 'border-[#C88A55] bg-[#C88A55]/10'
                    : 'border-[#D5CCC0] bg-white hover:border-[#4A2538]'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png,.docx"
                  onChange={(e) => handleFilesAdded(e.target.files)}
                  className="hidden"
                />
                <Upload className="w-6 h-6 text-[#4A2538] mx-auto mb-2" />
                <p className="text-sm font-medium text-[#1E1A1D]">
                  {t.calculator.dropzoneTitle}
                </p>
                <p className="text-xs text-[#5C5559] mt-1">{t.calculator.dropzoneSub}</p>
                <p className="text-[11px] font-mono text-[#4F5D52] mt-2">
                  {t.calculator.dropzoneFormats}
                </p>
              </div>

              {files.length > 0 && (
                <ul className="mt-3 space-y-2">
                  {files.map((item) => (
                    <li
                      key={item.id}
                      className="flex items-center justify-between gap-3 bg-white border border-[#E5DFD7] rounded-lg px-3 py-2"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {item.previewUrl ? (
                          <img
                            src={item.previewUrl}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 object-cover rounded border border-[#E5DFD7] shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded bg-[#F9F8F6] border border-[#E5DFD7] flex items-center justify-center shrink-0">
                            <FileText className="w-5 h-5 text-[#4A2538]" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-[#1E1A1D] truncate">
                            {item.name}
                          </p>
                          <p className="text-[11px] font-mono text-[#5C5559] tabular-nums">
                            {item.type} · {formatFileSize(item.size)}
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeFile(item.id)}
                        aria-label={`${t.calculator.removeFile} ${item.name}`}
                        className="p-2 text-[#5C5559] hover:text-red-700 cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* 7. Delivery Method */}
            <div>
              <label className="block text-sm font-semibold text-[#4A2538] mb-3">
                {t.calculator.stepDelivery}
              </label>
              <div className="space-y-2.5">
                {(['pickup', 'amana', 'dhl'] as DeliveryMethod[]).map((delKey) => {
                  const item = t.calculator.deliveries[delKey];
                  const fee = DELIVERY_FEE_MAD[delKey];
                  const active = delivery === delKey;
                  return (
                    <button
                      key={delKey}
                      type="button"
                      onClick={() => setDelivery(delKey)}
                      className={`w-full p-3.5 rounded-lg border text-start transition-colors cursor-pointer flex items-start justify-between gap-3 ${
                        active
                          ? 'bg-white border-[#4A2538] ring-1 ring-[#4A2538]'
                          : 'bg-white/80 border-[#DDD5CA] hover:border-[#4A2538]'
                      }`}
                    >
                      <div>
                        <p className="text-sm font-semibold text-[#1E1A1D]">{item.label}</p>
                        <p className="text-xs text-[#5C5559] mt-0.5">{item.desc}</p>
                      </div>
                      <span className="text-xs font-mono font-semibold text-[#4F5D52] tabular-nums shrink-0">
                        {fee === 0 ? '0 ' + currency : `+${formatCurrency(fee, currency)}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right 5 Columns: Live Summary & Order Submission */}
          <div className="lg:col-span-5 lg:sticky lg:top-24">
            {receipt ? (
              <div className="bg-white border border-[#4F5D52] rounded-xl p-6 sm:p-7 shadow-[0_14px_34px_-20px_rgba(79,93,82,0.3)]">
                <div className="flex items-start gap-3 pb-4 mb-4 border-b border-[#E5DFD7]">
                  <CheckCircle2 className="w-6 h-6 text-[#4F5D52] shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-serif-editorial text-2xl font-bold text-[#4A2538]">
                      {t.calculator.receiptTitle}
                    </h3>
                    <p className="text-xs text-[#5C5559] mt-1 leading-relaxed">
                      {t.calculator.receiptSubtitle}
                    </p>
                  </div>
                </div>

                <div className="bg-[#F9F8F6] rounded-lg p-4 space-y-2.5 text-xs mb-5">
                  <div className="flex justify-between">
                    <span className="text-[#5C5559]">{t.calculator.receiptRefLabel}</span>
                    <span className="font-mono font-bold text-[#4A2538] tabular-nums">
                      {receipt.referenceId}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#5C5559]">{t.calculator.stepDirection}</span>
                    <span className="font-semibold text-[#1E1A1D]">
                      {t.calculator.directions[receipt.direction]}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#5C5559]">{t.calculator.stepCategory}</span>
                    <span className="font-semibold text-[#1E1A1D]">
                      {t.calculator.categories[receipt.category].label}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#5C5559]">{t.calculator.stepDestination}</span>
                    <span className="font-semibold text-[#1E1A1D]">
                      {t.calculator.destinations[receipt.destination]}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#5C5559]">{t.calculator.stepPages}</span>
                    <span className="font-mono font-semibold text-[#1E1A1D] tabular-nums">
                      {receipt.pages}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#E5DFD7] text-sm">
                    <span className="font-bold text-[#4A2538]">{t.calculator.totalLabel}</span>
                    <span className="font-mono font-bold text-[#4A2538] tabular-nums">
                      {receipt.totalFormatted}
                    </span>
                  </div>
                </div>

                <div className="space-y-2.5">
                  <a
                    href={buildWhatsAppUrl(receipt.referenceId)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-[#4F5D52] hover:bg-[#3F4B42] rounded-lg transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{t.calculator.whatsappBtn}</span>
                  </a>

                  <a
                    href={buildMailtoUrl(receipt)}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-[#C88A55] hover:bg-[#B57743] rounded-lg transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    <span>{t.calculator.receiptSendEmail}</span>
                  </a>

                  <div className="grid grid-cols-2 gap-2.5 pt-1">
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-[#4A2538] border border-[#DDD5CA] hover:bg-[#F9F8F6] rounded-lg cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>{t.calculator.receiptPrint}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setReceipt(null)}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-[#5C5559] border border-[#DDD5CA] hover:bg-[#F9F8F6] rounded-lg cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>{t.calculator.receiptNewOrder}</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <form
                onSubmit={handleSubmitOrder}
                noValidate
                className="bg-white border border-[#DFD8CE] rounded-xl p-6 sm:p-7 shadow-[0_14px_34px_-22px_rgba(74,37,56,0.2)]"
              >
                <div className="flex items-center justify-between pb-4 mb-5 border-b border-[#EFEAE2]">
                  <h3 className="font-serif-editorial text-2xl font-bold text-[#4A2538]">
                    {t.calculator.summaryTitle}
                  </h3>
                  <span className="text-xs font-mono font-semibold text-[#4F5D52]">
                    {currency}
                  </span>
                </div>

                {/* Line Items */}
                <dl className="space-y-3 text-sm mb-5 pb-5 border-b border-[#EFEAE2]">
                  <div className="flex justify-between gap-4">
                    <dt className="text-[#5C5559]">{t.calculator.perPageLabel}</dt>
                    <dd className="font-mono font-medium text-[#1E1A1D] tabular-nums">
                      {formatCurrency(basePerPageMad, currency)}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-4">
                    <dt className="text-[#5C5559]">
                      {t.calculator.translationSubtotal} ({pages})
                    </dt>
                    <dd className="font-mono font-medium text-[#1E1A1D] tabular-nums">
                      {formatCurrency(translationMad, currency)}
                    </dd>
                  </div>
                  {expressSurchargeMad > 0 && (
                    <div className="flex justify-between gap-4">
                      <dt className="text-[#5C5559]">{t.calculator.expressSurcharge}</dt>
                      <dd className="font-mono font-medium text-[#C88A55] tabular-nums">
                        +{formatCurrency(expressSurchargeMad, currency)}
                      </dd>
                    </div>
                  )}
                  <div className="flex justify-between gap-4">
                    <dt className="text-[#5C5559]">{t.calculator.deliveryLabel}</dt>
                    <dd className="font-mono font-medium text-[#1E1A1D] tabular-nums">
                      {deliveryFeeMad === 0
                        ? formatCurrency(0, currency)
                        : formatCurrency(deliveryFeeMad, currency)}
                    </dd>
                  </div>
                  <div className="flex justify-between items-baseline pt-3 border-t border-dashed border-[#DFD8CE]">
                    <dt className="text-base font-bold text-[#4A2538]">
                      {t.calculator.totalLabel}
                    </dt>
                    <dd className="text-2xl font-mono font-bold text-[#4A2538] tabular-nums">
                      {formatCurrency(totalMad, currency)}
                    </dd>
                  </div>
                </dl>

                {/* Client Contact Fields */}
                <div className="space-y-3 mb-5">
                  <p className="text-xs font-semibold tracking-wide text-[#4F5D52]">
                    {t.calculator.clientSectionTitle}
                  </p>
                  <input
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder={t.calculator.namePlaceholder}
                    className="w-full px-3.5 py-2.5 text-sm bg-[#F9F8F6] border border-[#DDD5CA] rounded-lg focus:outline-none focus:bg-white focus:border-[#4A2538]"
                  />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      type="email"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                      placeholder={t.calculator.emailPlaceholder}
                      className="w-full px-3.5 py-2.5 text-sm bg-[#F9F8F6] border border-[#DDD5CA] rounded-lg focus:outline-none focus:bg-white focus:border-[#4A2538]"
                    />
                    <input
                      type="tel"
                      value={clientPhone}
                      onChange={(e) => setClientPhone(e.target.value)}
                      placeholder={t.calculator.phonePlaceholder}
                      className="w-full px-3.5 py-2.5 text-sm bg-[#F9F8F6] border border-[#DDD5CA] rounded-lg focus:outline-none focus:bg-white focus:border-[#4A2538]"
                    />
                  </div>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder={t.calculator.notesPlaceholder}
                    className="w-full px-3.5 py-2 text-sm bg-[#F9F8F6] border border-[#DDD5CA] rounded-lg focus:outline-none focus:bg-white focus:border-[#4A2538] resize-none"
                  />
                </div>

                {formError && (
                  <div
                    role="alert"
                    className="mb-4 flex items-start gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{formError}</span>
                  </div>
                )}

                {/* Dual Submission CTAs */}
                <div className="space-y-2.5">
                  <button
                    type="submit"
                    className="w-full py-3.5 px-5 text-sm font-semibold text-white bg-[#C88A55] hover:bg-[#B57743] rounded-lg transition-colors cursor-pointer min-h-[46px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4A2538]"
                  >
                    {t.calculator.submitOrderBtn}
                  </button>

                  <a
                    href={buildWhatsAppUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 py-3 px-5 text-sm font-semibold text-[#4A2538] bg-[#F9F8F6] border border-[#D8D0C6] hover:border-[#4F5D52] hover:text-[#4F5D52] rounded-lg transition-colors min-h-[44px]"
                  >
                    <MessageCircle className="w-4 h-4 text-[#4F5D52]" />
                    <span>{t.calculator.whatsappBtn}</span>
                  </a>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
