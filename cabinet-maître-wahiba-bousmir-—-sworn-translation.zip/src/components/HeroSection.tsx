import React, { useState } from 'react';
import { Check, MessageCircle, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language } from '../types/translation';
import { TranslationDictionary } from '../data/translations';
import { CrestLogo, OfficialStamp } from './CrestLogo';

interface HeroSectionProps {
  lang: Language;
  t: TranslationDictionary;
  onJumpToCalculator: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  lang,
  t,
  onJumpToCalculator,
}) => {
  const [certMode, setCertMode] = useState<'sworn' | 'apostille'>('sworn');
  const isRtl = lang === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  return (
    <section
      id="top"
      className="bg-gradient-to-b from-[#F9F8F6] to-white border-b border-[#E8E3DC]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-12 lg:pt-16 lg:pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Column: Core Proposition */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <p className="text-xs sm:text-[13px] font-semibold tracking-wide text-[#4F5D52] mb-4">
              {t.hero.kicker}
            </p>

            <h1
              className="font-serif-editorial text-[clamp(2.2rem,4vw,3.55rem)] font-bold leading-[1.12] tracking-tight text-[#4A2538] mb-5"
              style={{ textWrap: 'balance' }}
            >
              {t.hero.headline}
            </h1>

            <p className="text-base sm:text-[17px] leading-relaxed text-[#4F484C] max-w-2xl mb-7">
              {t.hero.subtitle}
            </p>

            {/* 4 Checkmark Highlights */}
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 mb-8">
              {t.hero.highlights.map((item, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-2.5 text-sm font-medium text-[#1E1A1D]"
                >
                  <span className="mt-0.5 w-5 h-5 rounded-full bg-[#4F5D52]/12 text-[#4F5D52] inline-flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5" strokeWidth={2.5} />
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            {/* Primary & Secondary CTAs */}
            <div className="flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={onJumpToCalculator}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold tracking-wide text-white bg-[#C88A55] hover:bg-[#B57743] rounded-md transition-colors cursor-pointer min-h-[46px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4A2538]"
              >
                <span>{t.hero.primaryCta}</span>
                <ArrowIcon className="w-4 h-4" />
              </button>

              <a
                href="https://wa.me/212690129797"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-semibold text-[#4A2538] bg-white border border-[#D8D0C6] hover:border-[#4A2538] hover:bg-[#F9F8F6] rounded-md transition-colors min-h-[46px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4A2538]"
              >
                <MessageCircle className="w-4 h-4 text-[#4F5D52]" />
                <span className="tabular-nums">{t.hero.secondaryCta}</span>
              </a>
            </div>
          </div>

          {/* Right Column: Official Stamped & Signed Certificate Specimen */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <div className="relative bg-white border border-[#DFD8CE] rounded-xl shadow-[0_18px_45px_-24px_rgba(74,37,56,0.22)] p-6 sm:p-7">
              {/* Format Inspection Switcher */}
              <div className="flex items-center justify-between gap-2 pb-4 mb-5 border-b border-[#EFEAE2]">
                <div className="flex items-center gap-2">
                  <CrestLogo className="w-7 h-7" variant="plum" />
                  <span className="text-xs font-mono font-medium text-[#5C5559] tabular-nums">
                    {t.hero.certDoc.regNo}
                  </span>
                </div>

                <div className="inline-flex items-center bg-[#F9F8F6] border border-[#E5DFD7] rounded-md p-0.5">
                  <button
                    type="button"
                    onClick={() => setCertMode('sworn')}
                    className={`px-2.5 py-1 text-[11px] font-semibold rounded transition-colors cursor-pointer whitespace-nowrap ${
                      certMode === 'sworn'
                        ? 'bg-[#4A2538] text-white'
                        : 'text-[#5C5559] hover:text-[#4A2538]'
                    }`}
                  >
                    {t.hero.certToggle.sworn}
                  </button>
                  <button
                    type="button"
                    onClick={() => setCertMode('apostille')}
                    className={`px-2.5 py-1 text-[11px] font-semibold rounded transition-colors cursor-pointer whitespace-nowrap ${
                      certMode === 'apostille'
                        ? 'bg-[#4A2538] text-white'
                        : 'text-[#5C5559] hover:text-[#4A2538]'
                    }`}
                  >
                    {t.hero.certToggle.apostille}
                  </button>
                </div>
              </div>

              {/* Certificate Inner Document Frame */}
              <div className="bg-[#F9F8F6] border border-[#E6E0D7] rounded-lg p-5 sm:p-6">
                <div className="text-center border-b border-[#DFD8CE] pb-4 mb-4">
                  <p className="text-[10px] font-semibold tracking-widest text-[#4F5D52] uppercase">
                    {t.hero.certDoc.headerTop}
                  </p>
                  <p className="text-xs font-medium text-[#5C5559] mt-1">
                    {t.hero.certDoc.headerSub}
                  </p>
                  <h2 className="font-serif-editorial text-xl font-bold text-[#4A2538] mt-3">
                    {certMode === 'sworn'
                      ? t.hero.certDoc.title
                      : t.hero.certDoc.apostilleTitle}
                  </h2>
                </div>

                <p className="text-[13px] leading-relaxed text-[#2C2629] mb-5">
                  {certMode === 'sworn'
                    ? t.hero.certDoc.bodySnippet
                    : t.hero.certDoc.apostilleSnippet}
                </p>

                {/* Signature & Official Stamp Footer */}
                <div className="flex items-end justify-between gap-4 pt-3 border-t border-dashed border-[#D6CEC2]">
                  <div>
                    <p className="text-[11px] font-medium text-[#5C5559]">
                      {t.hero.certDoc.attestation}
                    </p>
                    <p className="font-serif-editorial italic text-xl font-semibold text-[#4A2538] mt-1">
                      Wahiba Bousmir
                    </p>
                    <p className="text-[11px] text-[#4F5D52] mt-0.5">
                      {t.hero.certDoc.locationLine}
                    </p>
                  </div>

                  <div className="shrink-0 -rotate-6">
                    <OfficialStamp
                      sealLabel={t.hero.certDoc.sealLabel}
                      regNo={t.hero.certDoc.regNo}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width Accreditation Strip Below Hero Split */}
        <div className="mt-10 pt-6 border-t border-[#E8E3DC] grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {t.hero.stripItems.map((item, index) => (
            <div
              key={index}
              className="flex items-center gap-2.5 text-xs sm:text-[13px] font-medium text-[#4A2538]"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#C88A55] shrink-0" aria-hidden="true" />
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
