import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Currency, Language } from '../types/translation';
import { TranslationDictionary } from '../data/translations';
import { CrestLogo } from './CrestLogo';

interface NavbarProps {
  lang: Language;
  setLang: (l: Language) => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  t: TranslationDictionary;
  onJumpToCalculator: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  lang,
  setLang,
  currency,
  setCurrency,
  t,
  onJumpToCalculator,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { href: '#services', label: t.nav.services },
    { href: '#authorities', label: t.nav.authorities },
    { href: '#how-it-works', label: t.nav.howItWorks },
    { href: '#credentials', label: t.nav.credentials },
    { href: '#office', label: t.nav.office },
  ];

  const handleMobileNavClick = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E8E3DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Brand Wordmark + Custom W Crest */}
        <a
          href="#top"
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#4A2538] rounded"
        >
          <CrestLogo className="w-8 h-8 shrink-0" variant="plum" />
          <span className="font-serif-editorial text-lg sm:text-xl font-bold tracking-tight text-[#4A2538] whitespace-nowrap">
            {t.brand.name}
          </span>
        </a>

        {/* Zone 2: Single-line navigation links */}
        <nav
          aria-label="Primary"
          className="hidden xl:flex items-center gap-6 text-[13.5px] font-medium text-[#4F484C]"
        >
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#C88A55] hover:text-[#4A2538] transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#4A2538]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Language Switcher, Currency Toggle & Primary CTA */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Language Switcher EN | FR | AR */}
          <div
            role="group"
            aria-label="Language switcher"
            className="inline-flex items-center bg-[#F9F8F6] border border-[#E5DFD7] rounded-md p-0.5"
          >
            {(['en', 'fr', 'ar'] as Language[]).map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                className={`px-2 py-1 text-xs font-semibold rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  lang === code
                    ? 'bg-[#4A2538] text-white'
                    : 'text-[#5C5559] hover:text-[#4A2538]'
                }`}
              >
                {code.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Currency Toggle MAD / USD / EUR */}
          <div
            role="group"
            aria-label="Currency toggle"
            className="hidden sm:inline-flex items-center bg-[#F9F8F6] border border-[#E5DFD7] rounded-md p-0.5"
          >
            {(['MAD', 'USD', 'EUR'] as Currency[]).map((curr) => (
              <button
                key={curr}
                type="button"
                onClick={() => setCurrency(curr)}
                className={`px-2 py-1 text-xs font-mono font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  currency === curr
                    ? 'bg-[#4F5D52] text-white'
                    : 'text-[#5C5559] hover:text-[#4A2538]'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>

          {/* Primary Terracotta CTA */}
          <button
            type="button"
            onClick={onJumpToCalculator}
            className="hidden md:inline-flex items-center justify-center px-4 py-2 text-xs font-semibold tracking-wide text-white bg-[#C88A55] hover:bg-[#B57743] rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 min-h-[36px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#4A2538]"
          >
            {t.nav.cta}
          </button>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label="Toggle menu"
            className="xl:hidden inline-flex items-center justify-center w-10 h-10 rounded-md border border-[#E5DFD7] text-[#4A2538] hover:bg-[#F9F8F6] cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      {mobileOpen && (
        <div className="xl:hidden bg-white border-t border-[#E8E3DC] px-4 py-4 space-y-3">
          <div className="flex flex-col space-y-1">
            {navItems.map((item) => (
              <button
                key={item.href}
                type="button"
                onClick={() => handleMobileNavClick(item.href)}
                className="text-start py-2.5 px-3 text-sm font-medium text-[#1E1A1D] hover:bg-[#F9F8F6] rounded-md cursor-pointer"
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-[#E8E3DC] flex flex-wrap items-center justify-between gap-3">
            <div
              role="group"
              aria-label="Mobile currency toggle"
              className="sm:hidden inline-flex items-center bg-[#F9F8F6] border border-[#E5DFD7] rounded-md p-0.5"
            >
              {(['MAD', 'USD', 'EUR'] as Currency[]).map((curr) => (
                <button
                  key={curr}
                  type="button"
                  onClick={() => setCurrency(curr)}
                  className={`px-2.5 py-1.5 text-xs font-mono font-medium rounded cursor-pointer ${
                    currency === curr
                      ? 'bg-[#4F5D52] text-white'
                      : 'text-[#5C5559]'
                  }`}
                >
                  {curr}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onJumpToCalculator();
              }}
              className="w-full md:w-auto px-4 py-2.5 text-xs font-semibold text-white bg-[#C88A55] hover:bg-[#B57743] rounded-md cursor-pointer"
            >
              {t.nav.cta}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
