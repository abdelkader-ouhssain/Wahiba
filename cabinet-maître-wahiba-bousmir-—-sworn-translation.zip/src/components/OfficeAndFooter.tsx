import React from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  ExternalLink,
  MessageCircle,
  Landmark,
} from 'lucide-react';
import { Language } from '../types/translation';
import { TranslationDictionary } from '../data/translations';
import { CrestLogo } from './CrestLogo';

interface OfficeAndFooterProps {
  lang: Language;
  t: TranslationDictionary;
}

export const OfficeAndFooter: React.FC<OfficeAndFooterProps> = ({ lang, t }) => {
  const isRtl = lang === 'ar';
  const mapsSearchUrl =
    'https://www.google.com/maps/search/?api=1&query=Avenue+Ali+Yaata+Cour+d+appel+Tetouan+Morocco';

  return (
    <>
      {/* Office Location & Interactive Locator Card */}
      <section id="office" className="py-14 lg:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-10">
            <p className="text-xs font-semibold tracking-wide text-[#4F5D52] mb-2">
              {t.office.kicker}
            </p>
            <h2
              className="font-serif-editorial text-3xl sm:text-4xl font-bold text-[#4A2538] tracking-tight mb-3"
              style={{ textWrap: 'balance' }}
            >
              {t.office.title}
            </h2>
            <p className="text-base text-[#5C5559] leading-relaxed">
              {t.office.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            {/* Contact & Address Details */}
            <div className="lg:col-span-6 bg-[#F9F8F6] border border-[#E5DFD7] rounded-xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-5">
                {/* Address */}
                <div className="flex items-start gap-3.5">
                  <MapPin className="w-5 h-5 text-[#C88A55] shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-[#4F5D52] mb-1">
                      {t.office.addressLabel}
                    </p>
                    <p className="text-sm font-bold text-[#4A2538] leading-relaxed">
                      {t.office.addressLatin}
                    </p>
                    <p
                      dir="rtl"
                      className="text-sm font-medium text-[#5C5559] mt-1.5 leading-relaxed"
                    >
                      {t.office.addressArabic}
                    </p>
                  </div>
                </div>

                {/* Phone / WhatsApp */}
                <div className="flex items-start gap-3.5">
                  <Phone className="w-5 h-5 text-[#C88A55] shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-[#4F5D52] mb-1">
                      {t.office.phoneLabel}
                    </p>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                      <a
                        href="tel:+212690129797"
                        dir="ltr"
                        className="text-sm font-mono font-bold text-[#4A2538] hover:text-[#C88A55] tabular-nums"
                      >
                        +212 6 90 12 97 97
                      </a>
                      <a
                        href="https://wa.me/212690129797"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#4F5D52] hover:underline"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span dir="ltr">06 90 12 97 97</span>
                      </a>
                    </div>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3.5">
                  <Mail className="w-5 h-5 text-[#C88A55] shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-[#4F5D52] mb-1">
                      {t.office.emailLabel}
                    </p>
                    <a
                      href="mailto:wbousmir@gmail.com"
                      className="text-sm font-mono font-semibold text-[#4A2538] hover:text-[#C88A55]"
                    >
                      wbousmir@gmail.com
                    </a>
                  </div>
                </div>

                {/* Hours */}
                <div className="flex items-start gap-3.5">
                  <Clock className="w-5 h-5 text-[#C88A55] shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-[#4F5D52] mb-1">
                      {t.office.hoursLabel}
                    </p>
                    <p className="text-sm text-[#1E1A1D] tabular-nums">
                      {t.office.hoursValue}
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E5DFD7]">
                <a
                  href={mapsSearchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold text-white bg-[#4A2538] hover:bg-[#361928] rounded-md transition-colors"
                >
                  <span>{t.office.openMapsBtn}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Interactive Precision Architectural District Map Card */}
            <div className="lg:col-span-6 bg-[#F9F8F6] border border-[#E5DFD7] rounded-xl overflow-hidden flex flex-col justify-between">
              <div className="relative flex-1 min-h-[290px] bg-[#EFECE6] p-5 flex items-center justify-center">
                {/* Clean Architectural Vector Locator Map for Quartier Wilaya / Avenue Ali Yaâta */}
                <svg
                  viewBox="0 0 560 320"
                  className="w-full h-full max-h-[300px]"
                  role="img"
                  aria-label="Map of Cabinet Maître Wahiba Bousmir near Tétouan Court of Appeal"
                >
                  {/* City Blocks */}
                  <rect x="20" y="20" width="520" height="280" rx="10" fill="#F9F8F6" stroke="#DFD8CE" />
                  <rect x="50" y="45" width="145" height="90" rx="6" fill="#E8E3DC" />
                  <rect x="235" y="45" width="135" height="90" rx="6" fill="#E8E3DC" />
                  <rect x="405" y="45" width="110" height="90" rx="6" fill="#E8E3DC" />
                  <rect x="50" y="185" width="145" height="90" rx="6" fill="#E8E3DC" />
                  <rect x="235" y="185" width="280" height="90" rx="6" fill="#E8E3DC" />

                  {/* Avenue Ali Yaâta Horizontal Artery */}
                  <rect x="20" y="148" width="520" height="26" fill="#FFFFFF" stroke="#D4CBC0" strokeWidth="1" />
                  {/* Cross Street */}
                  <rect x="205" y="20" width="20" height="280" fill="#FFFFFF" stroke="#D4CBC0" strokeWidth="1" />

                  {/* Avenue Label */}
                  <text
                    x="390"
                    y="165"
                    fill="#5C5559"
                    fontSize="11"
                    fontWeight="600"
                    textAnchor="middle"
                  >
                    {t.office.mapAvenue}
                  </text>

                  {/* Quartier Wilaya Label */}
                  <text
                    x="120"
                    y="235"
                    fill="#4F5D52"
                    fontSize="11"
                    fontWeight="600"
                    textAnchor="middle"
                  >
                    {t.office.mapWilaya}
                  </text>

                  {/* Cour d'Appel Marker */}
                  <g transform="translate(122, 90)">
                    <rect
                      x="-62"
                      y="-24"
                      width="124"
                      height="48"
                      rx="6"
                      fill="#4F5D52"
                    />
                    <text
                      x="0"
                      y="-2"
                      fill="#FFFFFF"
                      fontSize="10"
                      fontWeight="700"
                      textAnchor="middle"
                    >
                      {t.office.mapCourAppel}
                    </text>
                    <text
                      x="0"
                      y="13"
                      fill="#E5DFD7"
                      fontSize="9"
                      textAnchor="middle"
                    >
                      Cour d&apos;appel · Tétouan
                    </text>
                  </g>

                  {/* Walking path connector */}
                  <path
                    d="M 184 95 L 300 95 L 300 198"
                    fill="none"
                    stroke="#C88A55"
                    strokeWidth="2.5"
                    strokeDasharray="5 4"
                  />

                  {/* Cabinet Marker Pin */}
                  <g transform="translate(300, 210)">
                    <circle cx="0" cy="0" r="18" fill="#4A2538" opacity="0.16" />
                    <circle cx="0" cy="0" r="9" fill="#C88A55" stroke="#FFFFFF" strokeWidth="2.5" />
                    <rect
                      x="-110"
                      y="16"
                      width="220"
                      height="26"
                      rx="5"
                      fill="#4A2538"
                    />
                    <text
                      x="0"
                      y="33"
                      fill="#FFFFFF"
                      fontSize="10"
                      fontWeight="700"
                      textAnchor="middle"
                    >
                      {t.office.mapCabinet}
                    </text>
                  </g>
                </svg>
              </div>

              <div className="p-5 sm:p-6 bg-white border-t border-[#E5DFD7] flex items-start gap-3">
                <Landmark className="w-5 h-5 text-[#4A2538] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#4A2538]">
                    {t.office.landmarkTitle}
                  </h3>
                  <p className="text-xs text-[#5C5559] mt-1 leading-relaxed">
                    {t.office.landmarkDesc}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Deep Plum Footer */}
      <footer className="bg-[#4A2538] text-white border-t border-[#361928]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-8 border-b border-white/15">
            <div className="md:col-span-5">
              <div className="flex items-center gap-3 mb-3">
                <CrestLogo className="w-9 h-9" variant="light" />
                <div>
                  <p className="font-serif-editorial text-xl font-bold text-white">
                    {t.brand.name}
                  </p>
                  <p className="text-xs text-[#C88A55] font-medium">
                    {t.brand.shortTitle}
                  </p>
                </div>
              </div>
              <p className="text-sm text-white/80 leading-relaxed max-w-md">
                {t.brand.title}
              </p>
            </div>

            <div className="md:col-span-3">
              <p className="text-xs font-semibold tracking-wide text-[#C88A55] mb-3">
                {t.footer.quickLinks}
              </p>
              <ul className="space-y-2 text-sm text-white/80">
                <li>
                  <a href="#calculator" className="hover:text-white transition-colors">
                    {t.nav.cta}
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    {t.nav.services}
                  </a>
                </li>
                <li>
                  <a href="#authorities" className="hover:text-white transition-colors">
                    {t.nav.authorities}
                  </a>
                </li>
                <li>
                  <a href="#office" className="hover:text-white transition-colors">
                    {t.nav.office}
                  </a>
                </li>
              </ul>
            </div>

            <div className="md:col-span-4">
              <p className="text-xs font-semibold tracking-wide text-[#C88A55] mb-3">
                {t.footer.credentialsTitle}
              </p>
              <p className="text-xs text-white/85 leading-relaxed mb-2">
                {t.brand.accreditation}
              </p>
              <p className="text-xs text-white/75 leading-relaxed">
                {t.brand.school}
              </p>
              <p className="text-xs font-mono text-[#C88A55] mt-3" dir="ltr">
                +212 6 90 12 97 97 · wbousmir@gmail.com
              </p>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/70">
            <p>{t.footer.copyright}</p>
            <p>{t.footer.tagline}</p>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Quick-Chat Button */}
      <a
        href="https://wa.me/212690129797"
        target="_blank"
        rel="noopener noreferrer"
        aria-label={t.whatsappFloat}
        className={`fixed bottom-5 z-30 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-[#4F5D52] hover:bg-[#3F4B42] text-white text-xs font-semibold shadow-lg transition-transform hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C88A55] ${
          isRtl ? 'left-5' : 'right-5'
        }`}
      >
        <MessageCircle className="w-4 h-4 shrink-0" />
        <span className="hidden sm:inline tabular-nums">{t.whatsappFloat}</span>
      </a>
    </>
  );
};
