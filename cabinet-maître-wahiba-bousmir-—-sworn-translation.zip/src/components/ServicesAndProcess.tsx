import React from 'react';
import { ArrowRight, ArrowLeft, ShieldCheck } from 'lucide-react';
import { DocumentCategory, Language } from '../types/translation';
import { TranslationDictionary } from '../data/translations';

interface ServicesAndProcessProps {
  lang: Language;
  t: TranslationDictionary;
  onSelectCategory: (cat: DocumentCategory) => void;
}

export const ServicesAndProcess: React.FC<ServicesAndProcessProps> = ({
  lang,
  t,
  onSelectCategory,
}) => {
  const isRtl = lang === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  return (
    <>
      {/* Accepted Authorities Section */}
      <section
        id="authorities"
        className="py-12 lg:py-16 bg-[#F9F8F6] border-b border-[#E8E3DC]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <p className="text-xs font-semibold tracking-wide text-[#4F5D52] mb-2">
                {t.authorities.kicker}
              </p>
              <h2
                className="font-serif-editorial text-2xl sm:text-3xl font-bold text-[#4A2538]"
                style={{ textWrap: 'balance' }}
              >
                {t.authorities.title}
              </h2>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {t.authorities.items.map((auth, idx) => (
              <div
                key={idx}
                className="bg-white border border-[#E5DFD7] rounded-lg p-4 sm:p-5 flex items-start gap-3"
              >
                <ShieldCheck className="w-5 h-5 text-[#4F5D52] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#4A2538]">{auth.name}</h3>
                  <p className="text-xs text-[#5C5559] mt-1 leading-relaxed">
                    {auth.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Core Services Grid (3 Editorial Cards) */}
      <section id="services" className="py-14 lg:py-20 bg-white border-b border-[#E8E3DC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-10">
            <p className="text-xs font-semibold tracking-wide text-[#4F5D52] mb-2">
              {t.services.kicker}
            </p>
            <h2
              className="font-serif-editorial text-3xl sm:text-4xl font-bold text-[#4A2538] tracking-tight mb-3"
              style={{ textWrap: 'balance' }}
            >
              {t.services.title}
            </h2>
            <p className="text-base text-[#5C5559] leading-relaxed">
              {t.services.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {t.services.cards.map((card) => (
              <article
                key={card.index}
                className="bg-[#F9F8F6] border border-[#E5DFD7] rounded-xl p-6 sm:p-7 flex flex-col justify-between hover:border-[#4A2538] transition-colors"
              >
                <div>
                  <span className="font-mono text-xs font-semibold text-[#C88A55] tabular-nums">
                    {card.index}
                  </span>
                  <h3 className="font-serif-editorial text-2xl font-bold text-[#4A2538] mt-2 mb-3">
                    {card.title}
                  </h3>
                  <p className="text-sm text-[#4F484C] leading-relaxed mb-4">
                    {card.description}
                  </p>
                  <p className="text-xs text-[#4F5D52] font-medium pb-5 border-b border-[#E5DFD7]">
                    {card.examples}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onSelectCategory(card.id)}
                  className="mt-5 inline-flex items-center gap-2 text-xs font-bold text-[#4A2538] hover:text-[#C88A55] transition-colors cursor-pointer self-start"
                >
                  <span>{t.services.selectAction}</span>
                  <ArrowIcon className="w-3.5 h-3.5" />
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* 4-Step Ordering Process */}
      <section
        id="how-it-works"
        className="py-14 lg:py-20 bg-[#4A2538] text-white"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-10">
            <p className="text-xs font-semibold tracking-wide text-[#C88A55] mb-2">
              {t.process.kicker}
            </p>
            <h2
              className="font-serif-editorial text-3xl sm:text-4xl font-bold text-white tracking-tight"
              style={{ textWrap: 'balance' }}
            >
              {t.process.title}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {t.process.steps.map((step) => (
              <div
                key={step.num}
                className="bg-white/5 border border-white/15 rounded-xl p-6 flex flex-col"
              >
                <span className="font-mono text-2xl font-bold text-[#C88A55] tabular-nums mb-4">
                  {step.num}
                </span>
                <h3 className="text-base font-bold text-white mb-2">{step.title}</h3>
                <p className="text-sm text-white/80 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};
