import React, { useState } from 'react';
import {
  Award,
  BookOpen,
  Scale,
  ArrowRight,
  ArrowLeft,
  Check,
} from 'lucide-react';
import { DocumentCategory, Language } from '../types/translation';
import { TranslationDictionary } from '../data/translations';
import { CrestLogo } from './CrestLogo';

interface UseCasesAndCabinetProps {
  lang: Language;
  t: TranslationDictionary;
  onSelectCategory: (cat: DocumentCategory) => void;
}

export const UseCasesAndCabinet: React.FC<UseCasesAndCabinetProps> = ({
  lang,
  t,
  onSelectCategory,
}) => {
  const [activeCaseId, setActiveCaseId] = useState<string>(t.useCases.cases[0].id);
  const [imgFailed, setImgFailed] = useState(false);

  const isRtl = lang === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;
  const activeCase =
    t.useCases.cases.find((c) => c.id === activeCaseId) || t.useCases.cases[0];

  return (
    <section
      id="credentials"
      className="py-14 lg:py-20 bg-[#F9F8F6] border-b border-[#E8E3DC]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Part 1: Interactive Use-Case Breakdown */}
        <div>
          <div className="max-w-3xl mb-8">
            <p className="text-xs font-semibold tracking-wide text-[#4F5D52] mb-2">
              {t.useCases.kicker}
            </p>
            <h2
              className="font-serif-editorial text-3xl sm:text-4xl font-bold text-[#4A2538] tracking-tight mb-3"
              style={{ textWrap: 'balance' }}
            >
              {t.useCases.title}
            </h2>
            <p className="text-base text-[#5C5559] leading-relaxed">
              {t.useCases.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Case Selector Tabs */}
            <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
              {t.useCases.cases.map((item) => {
                const isSelected = item.id === activeCase.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveCaseId(item.id)}
                    className={`p-4 rounded-xl border text-start transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#4A2538] text-white border-[#4A2538]'
                        : 'bg-white text-[#1E1A1D] border-[#E5DFD7] hover:border-[#4A2538]'
                    }`}
                  >
                    <p className="text-sm font-bold">{item.title}</p>
                    <p
                      className={`text-xs mt-1 line-clamp-1 ${
                        isSelected ? 'text-white/80' : 'text-[#5C5559]'
                      }`}
                    >
                      {item.documents}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Active Case Detail Card */}
            <div className="lg:col-span-7 bg-white border border-[#E5DFD7] rounded-xl p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <p className="text-xs font-semibold text-[#C88A55] mb-2">
                  {t.calculator.categories[activeCase.category].label}
                </p>
                <h3 className="font-serif-editorial text-2xl sm:text-3xl font-bold text-[#4A2538] mb-3">
                  {activeCase.title}
                </h3>
                <p className="text-sm sm:text-base text-[#4F484C] leading-relaxed mb-6">
                  {activeCase.detail}
                </p>

                <div className="bg-[#F9F8F6] border border-[#E8E3DC] rounded-lg p-4">
                  <p className="text-xs font-semibold text-[#4F5D52] mb-1.5">
                    {t.calculator.stepCategory}
                  </p>
                  <p className="text-sm font-medium text-[#1E1A1D]">
                    {activeCase.documents}
                  </p>
                </div>
              </div>

              <div className="mt-6 pt-5 border-t border-[#EFEAE2] flex items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => onSelectCategory(activeCase.category)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#C88A55] hover:bg-[#B57743] rounded-md transition-colors cursor-pointer"
                >
                  <span>{t.services.selectAction}</span>
                  <ArrowIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Part 2: Why Choose Our Cabinet & Official Credentials + Editorial Photo */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch pt-4 border-t border-[#E5DFD7]">
          {/* Editorial Cabinet Image */}
          <div className="lg:col-span-5 flex flex-col">
            <div className="relative flex-1 min-h-[280px] rounded-xl overflow-hidden border border-[#DFD8CE] bg-[#4A2538]">
              {!imgFailed ? (
                <img
                  src="/src/assets/images/cabinet_sworn_desk_1794672160940.jpg"
                  alt="Cabinet Maître Wahiba Bousmir — Sworn Translation Desk in Tétouan"
                  referrerPolicy="no-referrer"
                  onError={() => setImgFailed(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center text-white">
                  <CrestLogo className="w-16 h-16 mb-3" variant="light" />
                  <p className="font-serif-editorial text-2xl font-bold">
                    {t.brand.name}
                  </p>
                  <p className="text-xs text-white/80 mt-1">{t.brand.shortTitle}</p>
                </div>
              )}
            </div>
          </div>

          {/* Why Choose + Credentials */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            <div>
              <h3 className="font-serif-editorial text-2xl sm:text-3xl font-bold text-[#4A2538] mb-5">
                {t.useCases.whyTitle}
              </h3>

              <div className="space-y-4">
                {t.useCases.whyPoints.map((pt, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <span className="mt-0.5 w-5 h-5 rounded-full bg-[#4F5D52]/15 text-[#4F5D52] inline-flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5" strokeWidth={2.5} />
                    </span>
                    <div>
                      <h4 className="text-sm font-bold text-[#1E1A1D]">{pt.title}</h4>
                      <p className="text-sm text-[#5C5559] leading-relaxed mt-0.5">
                        {pt.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Official Credentials Summary Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-5 border-t border-[#E5DFD7]">
              <div className="bg-white border border-[#E5DFD7] rounded-lg p-4">
                <BookOpen className="w-4 h-4 text-[#C88A55] mb-2" />
                <p className="text-[11px] font-semibold text-[#4F5D52]">
                  {t.useCases.credentialsCard.schoolLabel}
                </p>
                <p className="text-xs font-bold text-[#4A2538] mt-1 leading-snug">
                  {t.useCases.credentialsCard.schoolValue}
                </p>
              </div>

              <div className="bg-white border border-[#E5DFD7] rounded-lg p-4">
                <Award className="w-4 h-4 text-[#C88A55] mb-2" />
                <p className="text-[11px] font-semibold text-[#4F5D52]">
                  {t.useCases.credentialsCard.atajLabel}
                </p>
                <p className="text-xs font-bold text-[#4A2538] mt-1 leading-snug">
                  {t.useCases.credentialsCard.atajValue}
                </p>
              </div>

              <div className="bg-white border border-[#E5DFD7] rounded-lg p-4">
                <Scale className="w-4 h-4 text-[#C88A55] mb-2" />
                <p className="text-[11px] font-semibold text-[#4F5D52]">
                  {t.useCases.credentialsCard.pairLabel}
                </p>
                <p className="text-xs font-bold text-[#4A2538] mt-1 leading-snug">
                  {t.useCases.credentialsCard.pairValue}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
