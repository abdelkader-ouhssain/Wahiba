export type Language = 'en' | 'fr' | 'ar';
export type Currency = 'MAD' | 'USD' | 'EUR';

export type DirectionPair = 'ar-en' | 'en-ar';

export type DocumentCategory =
  | 'civil'
  | 'academic'
  | 'legal'
  | 'corporate'
  | 'immigration';

export type DestinationAuthority =
  | 'morocco'
  | 'usa'
  | 'canada'
  | 'uk'
  | 'eu';

export type DeliveryMethod = 'pickup' | 'amana' | 'dhl';
export type TurnaroundSpeed = 'standard' | 'express';

export interface UploadedFileItem {
  id: string;
  name: string;
  size: number;
  type: string;
  previewUrl?: string;
}

export interface OrderReceipt {
  referenceId: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  direction: DirectionPair;
  category: DocumentCategory;
  destination: DestinationAuthority;
  pages: number;
  turnaround: TurnaroundSpeed;
  delivery: DeliveryMethod;
  notes: string;
  files: string[];
  totalFormatted: string;
  currency: Currency;
  createdAt: string;
}
