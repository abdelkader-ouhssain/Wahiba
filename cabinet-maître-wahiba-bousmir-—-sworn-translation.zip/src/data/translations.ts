import {
  Currency,
  DeliveryMethod,
  DestinationAuthority,
  DocumentCategory,
  Language,
} from '../types/translation';

export const CURRENCY_RATES: Record<Currency, { symbol: string; rate: number; code: string }> = {
  MAD: { symbol: 'MAD', rate: 1, code: 'MAD' },
  USD: { symbol: '$', rate: 0.1, code: 'USD' },
  EUR: { symbol: '€', rate: 0.092, code: 'EUR' },
};

export const CATEGORY_BASE_MAD: Record<DocumentCategory, number> = {
  civil: 150,
  academic: 180,
  legal: 240,
  corporate: 260,
  immigration: 190,
};

export const DELIVERY_FEE_MAD: Record<DeliveryMethod, number> = {
  pickup: 0,
  amana: 50,
  dhl: 350,
};

export const EXPRESS_MULTIPLIER = 1.35;

export function formatCurrency(amountMad: number, currency: Currency): string {
  const { symbol, rate } = CURRENCY_RATES[currency];
  const converted = Math.round(amountMad * rate);
  if (currency === 'MAD') {
    return `${converted.toLocaleString('en-US')} MAD`;
  }
  return `${symbol}${converted.toLocaleString('en-US')}`;
}

export interface TranslationDictionary {
  brand: {
    name: string;
    arabicName: string;
    title: string;
    shortTitle: string;
    school: string;
    accreditation: string;
    pair: string;
    partnerNote: string;
  };
  nav: {
    services: string;
    authorities: string;
    howItWorks: string;
    credentials: string;
    office: string;
    cta: string;
  };
  hero: {
    kicker: string;
    headline: string;
    subtitle: string;
    highlights: string[];
    primaryCta: string;
    secondaryCta: string;
    stripItems: string[];
    certToggle: {
      sworn: string;
      apostille: string;
    };
    certDoc: {
      headerTop: string;
      headerSub: string;
      title: string;
      apostilleTitle: string;
      bodySnippet: string;
      apostilleSnippet: string;
      attestation: string;
      sealLabel: string;
      regNo: string;
      locationLine: string;
    };
  };
  calculator: {
    sectionKicker: string;
    sectionTitle: string;
    sectionSubtitle: string;
    stepDirection: string;
    directions: {
      'ar-en': string;
      'en-ar': string;
    };
    partnerHint: string;
    stepCategory: string;
    categories: Record<DocumentCategory, { label: string; desc: string }>;
    stepDestination: string;
    destinations: Record<DestinationAuthority, string>;
    stepSpeed: string;
    speeds: {
      standard: { label: string; time: string };
      express: { label: string; time: string };
    };
    stepPages: string;
    pagesUnit: string;
    stepUpload: string;
    dropzoneTitle: string;
    dropzoneSub: string;
    dropzoneFormats: string;
    removeFile: string;
    stepDelivery: string;
    deliveries: Record<DeliveryMethod, { label: string; desc: string }>;
    summaryTitle: string;
    perPageLabel: string;
    translationSubtotal: string;
    expressSurcharge: string;
    deliveryLabel: string;
    totalLabel: string;
    clientSectionTitle: string;
    namePlaceholder: string;
    emailPlaceholder: string;
    phonePlaceholder: string;
    notesPlaceholder: string;
    submitOrderBtn: string;
    whatsappBtn: string;
    validationError: string;
    receiptTitle: string;
    receiptSubtitle: string;
    receiptRefLabel: string;
    receiptSendEmail: string;
    receiptPrint: string;
    receiptNewOrder: string;
  };
  authorities: {
    kicker: string;
    title: string;
    items: { name: string; detail: string }[];
  };
  services: {
    kicker: string;
    title: string;
    subtitle: string;
    selectAction: string;
    cards: {
      id: DocumentCategory;
      index: string;
      title: string;
      description: string;
      examples: string;
    }[];
  };
  process: {
    kicker: string;
    title: string;
    steps: {
      num: string;
      title: string;
      desc: string;
    }[];
  };
  useCases: {
    kicker: string;
    title: string;
    subtitle: string;
    cases: {
      id: string;
      title: string;
      documents: string;
      detail: string;
      category: DocumentCategory;
    }[];
    whyTitle: string;
    whyPoints: {
      title: string;
      desc: string;
    }[];
    credentialsCard: {
      schoolLabel: string;
      schoolValue: string;
      atajLabel: string;
      atajValue: string;
      pairLabel: string;
      pairValue: string;
    };
  };
  office: {
    kicker: string;
    title: string;
    subtitle: string;
    addressLabel: string;
    addressLatin: string;
    addressArabic: string;
    hoursLabel: string;
    hoursValue: string;
    phoneLabel: string;
    emailLabel: string;
    landmarkTitle: string;
    landmarkDesc: string;
    openMapsBtn: string;
    mapCourAppel: string;
    mapCabinet: string;
    mapAvenue: string;
    mapWilaya: string;
  };
  footer: {
    copyright: string;
    tagline: string;
    quickLinks: string;
    credentialsTitle: string;
  };
  whatsappFloat: string;
}

export const DICTIONARY: Record<Language, TranslationDictionary> = {
  en: {
    brand: {
      name: 'Maître Wahiba Bousmir',
      arabicName: 'الأستاذة وهيبة بوسمير',
      title: 'Sworn Translator Accepted Before Courts & Consulates',
      shortTitle: 'Sworn Translator · Arabic ↔ English',
      school: 'Graduate of King Fahd School of Translation',
      accreditation: 'Member of ATAJ · Accredited by the Ministry of Justice',
      pair: 'Arabic ↔ English',
      partnerNote: 'Partner network support available for French & Spanish documents.',
    },
    nav: {
      services: 'Services',
      authorities: 'Authorities',
      howItWorks: 'How It Works',
      credentials: 'Credentials',
      office: 'Office & Contact',
      cta: 'Instant Quote',
    },
    hero: {
      kicker: 'Accredited by the Ministry of Justice · Member of ATAJ',
      headline: 'Sworn Arabic ↔ English Translations Accepted Worldwide',
      subtitle:
        'Official court-certified translations by Maître Wahiba Bousmir, graduate of King Fahd School of Translation. Fast digital delivery & worldwide courier shipping from Tétouan.',
      highlights: [
        'Express 12–24h Turnaround',
        'Valid for Embassies, Consulates, USCIS, IRCC & Courts',
        'Apostille & Legalisation Guidance',
        'Direct WhatsApp & Online Ordering',
      ],
      primaryCta: 'ORDER YOUR TRANSLATION',
      secondaryCta: 'Chat on WhatsApp (06 90 12 97 97)',
      stripItems: [
        'ATAJ Member',
        'Ministry of Justice Accredited',
        'King Fahd School of Translation Alumna',
        'Tétouan Court of Appeal Jurisdiction',
      ],
      certToggle: {
        sworn: 'Sworn Certificate',
        apostille: 'Apostille Ready',
      },
      certDoc: {
        headerTop: 'KINGDOM OF MOROCCO · COURT OF APPEAL OF TÉTOUAN',
        headerSub: 'Cabinet Maître Wahiba Bousmir · Sworn Translator',
        title: 'CERTIFIED SWORN TRANSLATION',
        apostilleTitle: 'APOSTILLE & CONSULAR COMPLIANCE',
        bodySnippet:
          'I, the undersigned, Maître Wahiba Bousmir, Sworn Translator accredited before the Courts of the Kingdom of Morocco (Arabic ↔ English), hereby certify that the foregoing translation is true, faithful, and conforms to the original document presented.',
        apostilleSnippet:
          'Prepared in strict compliance with the Hague Apostille Convention and Ministry of Foreign Affairs legalisation standards for USCIS, IRCC, UK Home Office, and Schengen consular submissions.',
        attestation: 'Signed, sealed & registered in Tétouan',
        sealLabel: 'SWORN TRANSLATOR · ATAJ',
        regNo: 'Ref. WB-AR/EN-2026',
        locationLine: 'Avenue Ali Yaâta, Immeuble Jebli · Tétouan',
      },
    },
    calculator: {
      sectionKicker: 'Self-Service Quote & Upload',
      sectionTitle: 'Instant Quote & Document Upload',
      sectionSubtitle:
        'Configure your sworn translation below to view transparent pricing and submit your documents directly to Maître Wahiba Bousmir.',
      stepDirection: '1. Language Direction',
      directions: {
        'ar-en': 'Arabic → English',
        'en-ar': 'English → Arabic',
      },
      partnerHint:
        'Need French or Spanish? Ask in notes — handled through our accredited ATAJ partner network.',
      stepCategory: '2. Document Category',
      categories: {
        civil: {
          label: 'Civil Status',
          desc: 'Birth, marriage, divorce, police record (casier judiciaire), family booklet',
        },
        academic: {
          label: 'Academic & Equivalency',
          desc: 'Diplomas, transcripts, enrollment letters, degree equivalency',
        },
        legal: {
          label: 'Legal & Court Judgments',
          desc: 'Court rulings, notarized deeds, adoul acts, powers of attorney',
        },
        corporate: {
          label: 'Corporate & Commercial',
          desc: 'Articles of association, contracts, trade register extracts, audits',
        },
        immigration: {
          label: 'Immigration & Visa Files',
          desc: 'USCIS, IRCC, UKVI, Schengen sponsorship & supporting dossiers',
        },
      },
      stepDestination: '3. Destination Country / Authority',
      destinations: {
        morocco: 'Morocco (Courts / Ministries)',
        usa: 'USA (USCIS / State Dept)',
        canada: 'Canada (IRCC / WES)',
        uk: 'United Kingdom (Home Office)',
        eu: 'EU / Embassies & Consulates',
      },
      stepSpeed: '4. Turnaround Speed',
      speeds: {
        standard: { label: 'Standard', time: '24–48 hours' },
        express: { label: 'Express Priority', time: '12–24 hours' },
      },
      stepPages: '5. Estimated Page Count',
      pagesUnit: 'pages',
      stepUpload: '6. Upload Documents (Optional Preview)',
      dropzoneTitle: 'Drag & drop files here, or click to browse',
      dropzoneSub: 'Files remain private in your session for preview & reference.',
      dropzoneFormats: 'Supported: PDF, JPG, PNG, DOCX',
      removeFile: 'Remove',
      stepDelivery: '7. Delivery & Certification Method',
      deliveries: {
        pickup: {
          label: 'Certified Digital PDF + Office Pickup (Tétouan)',
          desc: 'Stamped scan by email/WhatsApp + physical originals at Immeuble Jebli, near Court of Appeal',
        },
        amana: {
          label: 'Certified PDF + Amana Express (Morocco)',
          desc: 'Tracked national delivery of stamped originals anywhere in Morocco',
        },
        dhl: {
          label: 'Certified PDF + DHL International Express',
          desc: 'Priority international courier shipping for stamped hard copies worldwide',
        },
      },
      summaryTitle: 'Order Summary',
      perPageLabel: 'Rate per page',
      translationSubtotal: 'Sworn translation',
      expressSurcharge: 'Express priority (12–24h)',
      deliveryLabel: 'Delivery & shipping',
      totalLabel: 'Estimated Total',
      clientSectionTitle: 'Your Contact Details',
      namePlaceholder: 'Full Name *',
      emailPlaceholder: 'Email Address *',
      phonePlaceholder: 'Phone / WhatsApp (+212...) *',
      notesPlaceholder: 'Optional notes (e.g., spelling of passport names, Apostille needed)',
      submitOrderBtn: 'Submit Online Order Summary',
      whatsappBtn: 'Send Order to WhatsApp',
      validationError: 'Please enter your full name, a valid email address, and a phone number.',
      receiptTitle: 'Order Summary Prepared',
      receiptSubtitle:
        'Your quote reference is ready. Send it via email or WhatsApp to finalize document verification with Maître Wahiba Bousmir.',
      receiptRefLabel: 'Reference',
      receiptSendEmail: 'Send via Email (wbousmir@gmail.com)',
      receiptPrint: 'Print / Save PDF Summary',
      receiptNewOrder: 'Start New Quote',
    },
    authorities: {
      kicker: 'Institutional Recognition',
      title: 'Accepted by Courts, Ministries & Consulates Worldwide',
      items: [
        { name: 'Moroccan Courts & Ministries', detail: 'Courts of Appeal, First Instance, Wilayas & Prefectures' },
        { name: 'USA · USCIS', detail: 'Certified translations with signed accuracy attestation' },
        { name: 'Canada · IRCC & WES', detail: 'Express Entry, study permits & credential assessments' },
        { name: 'UK Home Office', detail: 'Visa, settlement & British citizenship submissions' },
        { name: 'EU & Schengen Consulates', detail: 'Visa centers, family reunification & civil registration' },
        { name: 'Hague Apostille Ready', detail: 'Formatted for Court of Appeal & Ministry legalisation' },
      ],
    },
    services: {
      kicker: 'Specialized Legal & Academic Practice',
      title: 'Core Sworn Translation Services',
      subtitle:
        'Every document is personally translated, verified, stamped, and signed by Maître Wahiba Bousmir—with zero outsourcing.',
      selectAction: 'Configure in Quote Calculator',
      cards: [
        {
          id: 'civil',
          index: '01',
          title: 'Sworn Translations (Arabic ↔ English)',
          description:
            'Official stamped and signed hard copies paired with high-resolution certified digital scans accepted by courts, embassies, and universities.',
          examples: 'Birth & marriage acts · Police clearance · Passports · Judgments',
        },
        {
          id: 'immigration',
          index: '02',
          title: 'Immigration & Academic Packages',
          description:
            'Complete bundled translation for visa files, study abroad admissions, degree equivalency (équivalence), and family reunification dossiers.',
          examples: 'USCIS · IRCC · UKVI · University transcripts · Diplomas',
        },
        {
          id: 'legal',
          index: '03',
          title: 'Legal, Commercial & Apostille Assistance',
          description:
            'Precision translation of contracts, articles of association, and powers of attorney, with step-by-step guidance for Apostille and Foreign Affairs legalisation.',
          examples: 'Corporate bylaws · Powers of attorney · Court orders · Apostille',
        },
      ],
    },
    process: {
      kicker: 'Transparent Workflow',
      title: 'From Document Upload to Official Seal in 4 Steps',
      steps: [
        {
          num: '01',
          title: 'Upload Your Documents',
          desc: 'Drop clear scans or photos (PDF, JPG, PNG, DOCX) in the calculator or send directly via WhatsApp.',
        },
        {
          num: '02',
          title: 'Confirm Language & Delivery',
          desc: 'Select Arabic ↔ English direction, destination authority, turnaround speed, and pickup or courier delivery.',
        },
        {
          num: '03',
          title: 'Sworn Translation & Verification',
          desc: 'Maître Wahiba Bousmir translates and checks passport spellings, legal terminology, and formatting.',
        },
        {
          num: '04',
          title: 'Receive Stamped Originals or PDF',
          desc: 'Get your certified PDF immediately upon completion and collect originals in Tétouan or via DHL/Amana.',
        },
      ],
    },
    useCases: {
      kicker: 'Client Solutions & Credentials',
      title: 'Built for Critical Legal, Academic & Immigration Milestones',
      subtitle:
        'Select a scenario below to inspect required documents, or review the official credentials backing every stamped page.',
      cases: [
        {
          id: 'visas',
          title: 'Visas & Immigration',
          documents: 'Birth certificates, police clearance, bank statements, employment letters, marriage acts',
          detail:
            'Formatted specifically for USCIS, IRCC, UKVI, and consulates with exact transliteration matching passport MRZ lines.',
          category: 'immigration',
        },
        {
          id: 'study',
          title: 'Studying Abroad',
          documents: 'Baccalauréat, university transcripts, diplomas, syllabus descriptions, recommendation letters',
          detail:
            'Accepted by international admissions boards, scholarship committees, WES, and Ministry equivalency commissions.',
          category: 'academic',
        },
        {
          id: 'family',
          title: 'Marriage & Family Civil Records',
          documents: 'Adoul marriage contracts, celibacy certificates, family booklets, custody & divorce decrees',
          detail:
            'Careful rendering of Moroccan civil and family law terminology (Moudawana) ready for Apostille and consular transcription.',
          category: 'civil',
        },
        {
          id: 'business',
          title: 'Business & Court Litigation',
          documents: 'Contracts, commercial registry (RC), powers of attorney, arbitral awards, court judgments',
          detail:
            'Strict confidentiality and binding legal precision prepared directly by an ATAJ-registered court sworn translator.',
          category: 'corporate',
        },
      ],
      whyTitle: 'Why Work Directly With Our Cabinet',
      whyPoints: [
        {
          title: 'Direct Sworn Translator — Zero Middlemen',
          desc: 'You communicate directly with Maître Wahiba Bousmir from quote to final seal, avoiding agency markups and delays.',
        },
        {
          title: 'King Fahd School of Translation Rigor',
          desc: 'Trained at Morocco’s premier translation institution in Tangier, ensuring terminological mastery across legal and technical fields.',
        },
        {
          title: 'Strict Confidentiality & Data Discretion',
          desc: 'Personal civil records, medical files, and corporate contracts are handled under professional judicial oath.',
        },
      ],
      credentialsCard: {
        schoolLabel: 'Academic Qualification',
        schoolValue: 'Graduate of King Fahd School of Translation (Tangier)',
        atajLabel: 'Official Sworn Accreditation',
        atajValue: 'Member of ATAJ · Accredited by the Ministry of Justice',
        pairLabel: 'Primary Sworn Pair',
        pairValue: 'Arabic ↔ English (French & Spanish partner network)',
      },
    },
    office: {
      kicker: 'Tétouan Cabinet & Direct Contact',
      title: 'Visit the Office Near the Court of Appeal',
      subtitle:
        'Conveniently situated in Quartier Wilaya for immediate document drop-off, original seal pickup, and Apostille guidance.',
      addressLabel: 'Office Address',
      addressLatin:
        "Quartier Wilaya, Avenue Ali Yaâta, près de la Cour d'appel, Immeuble Jebli, entre-sol (bloc 9), Tétouan, Morocco",
      addressArabic:
        'حي الولاية، شارع علي يعتة، قرب محكمة الاستئناف، عمارة الجبلي، الطابق السفلي (البلوك 9)، تطوان',
      hoursLabel: 'Office Hours',
      hoursValue: 'Monday – Friday: 09:00 – 17:30 · Saturday: 09:30 – 13:00',
      phoneLabel: 'Phone & WhatsApp',
      emailLabel: 'Direct Email',
      landmarkTitle: 'Prime Judicial District Location',
      landmarkDesc:
        'Two minutes on foot from the Tétouan Court of Appeal (Cour d’appel) — ideal when pairing sworn translations with court Apostille authentication.',
      openMapsBtn: 'Open Directions in Google Maps',
      mapCourAppel: 'Court of Appeal',
      mapCabinet: 'Cabinet W. Bousmir · Immeuble Jebli (Bloc 9)',
      mapAvenue: 'Avenue Ali Yaâta',
      mapWilaya: 'Quartier Wilaya',
    },
    footer: {
      copyright: '© 2026 Cabinet Maître Wahiba Bousmir. All rights reserved.',
      tagline: 'Sworn Translator Accepted Before Courts & Consulates · Arabic ↔ English',
      quickLinks: 'Navigation',
      credentialsTitle: 'Official Accreditation',
    },
    whatsappFloat: 'WhatsApp: 06 90 12 97 97',
  },
  fr: {
    brand: {
      name: 'Maître Wahiba Bousmir',
      arabicName: 'الأستاذة وهيبة بوسمير',
      title: 'Traductrice Assermentée près les Juridictions et Consulats',
      shortTitle: 'Traductrice Assermentée · Arabe ↔ Anglais',
      school: "Diplômée de l'École Supérieure Roi Fahd de Traduction",
      accreditation: 'Membre de l’ATAJ · Agréée par le Ministère de la Justice',
      pair: 'Arabe ↔ Anglais',
      partnerNote: 'Réseau de partenaires agréés disponible pour le français et l’espagnol.',
    },
    nav: {
      services: 'Services',
      authorities: 'Autorités',
      howItWorks: 'Procédure',
      credentials: 'Accréditations',
      office: 'Cabinet & Contact',
      cta: 'Devis Immédiat',
    },
    hero: {
      kicker: 'Agréée par le Ministère de la Justice · Membre de l’ATAJ',
      headline: 'Traductions Assermentées Arabe ↔ Anglais Reconnues à l’International',
      subtitle:
        "Traductions officielles certifiées par Maître Wahiba Bousmir, diplômée de l'École Supérieure Roi Fahd de Traduction. Envoi numérique rapide et expédition internationale depuis Tétouan.",
      highlights: [
        'Délai Express 12–24h',
        'Valable pour Ambassades, Consulats, USCIS, IRCC & Tribunaux',
        'Accompagnement Apostille & Légalisation',
        'Commande directe en ligne & WhatsApp',
      ],
      primaryCta: 'COMMANDER VOTRE TRADUCTION',
      secondaryCta: 'WhatsApp Direct (06 90 12 97 97)',
      stripItems: [
        'Membre de l’ATAJ',
        'Agréée Ministère de la Justice',
        'Lauréate École Roi Fahd de Traduction',
        'Ressort Cour d’Appel de Tétouan',
      ],
      certToggle: {
        sworn: 'Certificat Assermenté',
        apostille: 'Format Apostille',
      },
      certDoc: {
        headerTop: 'ROYAUME DU MAROC · COUR D’APPEL DE TÉTOUAN',
        headerSub: 'Cabinet Maître Wahiba Bousmir · Traductrice Assermentée',
        title: 'TRADUCTION OFFICIELLE CERTIFIÉE',
        apostilleTitle: 'CONFORMITÉ APOSTILLE & CONSULATS',
        bodySnippet:
          'Je soussignée, Maître Wahiba Bousmir, Traductrice Assermentée près les Juridictions du Royaume du Maroc (Arabe ↔ Anglais), certifie que la présente traduction est sincère, fidèle et conforme à l’original présenté.',
        apostilleSnippet:
          'Établie conformément aux exigences de la Convention de La Haye (Apostille) et du Ministère des Affaires Étrangères pour les dossiers USCIS, IRCC, Home Office et consulats Schengen.',
        attestation: 'Signée, scellée et enregistrée à Tétouan',
        sealLabel: 'TRADUCTRICE ASSERMENTÉE · ATAJ',
        regNo: 'Réf. WB-AR/EN-2026',
        locationLine: 'Avenue Ali Yaâta, Immeuble Jebli · Tétouan',
      },
    },
    calculator: {
      sectionKicker: 'Calculateur & Dépôt en Ligne',
      sectionTitle: 'Devis Instantané & Envoi de Documents',
      sectionSubtitle:
        'Configurez votre traduction assermentée ci-dessous pour obtenir un tarif transparent et transmettre vos pièces directement au cabinet.',
      stepDirection: '1. Sens de traduction',
      directions: {
        'ar-en': 'Arabe → Anglais',
        'en-ar': 'Anglais → Arabe',
      },
      partnerHint:
        'Besoin de français ou d’espagnol ? Précisez-le en note — pris en charge via notre réseau de confrères ATAJ.',
      stepCategory: '2. Catégorie de document',
      categories: {
        civil: {
          label: 'État Civil',
          desc: 'Acte de naissance, mariage, divorce, casier judiciaire, livret de famille',
        },
        academic: {
          label: 'Académique & Équivalence',
          desc: 'Diplômes, relevés de notes, attestations, dossiers d’équivalence',
        },
        legal: {
          label: 'Juridique & Jugements',
          desc: 'Jugements, actes adoulaires, actes notariés, procurations',
        },
        corporate: {
          label: 'Sociétés & Commercial',
          desc: 'Statuts, contrats commerciaux, extraits RC, bilans',
        },
        immigration: {
          label: 'Dossiers Visa & Immigration',
          desc: 'Dossiers USCIS, IRCC, UKVI, visas Schengen et regroupement familial',
        },
      },
      stepDestination: '3. Pays / Autorité destinataire',
      destinations: {
        morocco: 'Maroc (Tribunaux / Ministères)',
        usa: 'États-Unis (USCIS / Dept of State)',
        canada: 'Canada (IRCC / WES)',
        uk: 'Royaume-Uni (Home Office)',
        eu: 'UE / Ambassades & Consulats',
      },
      stepSpeed: '4. Délai de traitement',
      speeds: {
        standard: { label: 'Standard', time: '24–48 heures' },
        express: { label: 'Priorité Express', time: '12–24 heures' },
      },
      stepPages: '5. Nombre de pages estimé',
      pagesUnit: 'pages',
      stepUpload: '6. Joindre vos documents (Aperçu)',
      dropzoneTitle: 'Glissez-déposez vos fichiers ici, ou cliquez pour parcourir',
      dropzoneSub: 'Aperçu local sécurisé dans votre navigateur avant envoi.',
      dropzoneFormats: 'Formats acceptés : PDF, JPG, PNG, DOCX',
      removeFile: 'Retirer',
      stepDelivery: '7. Mode de remise & livraison',
      deliveries: {
        pickup: {
          label: 'PDF Certifié + Retrait au Cabinet (Tétouan)',
          desc: 'Scan cacheté par e-mail/WhatsApp + originaux à l’Immeuble Jebli, près de la Cour d’appel',
        },
        amana: {
          label: 'PDF Certifié + Amana Express (Maroc)',
          desc: 'Envoi national suivi des originaux cachetés partout au Maroc',
        },
        dhl: {
          label: 'PDF Certifié + DHL Express International',
          desc: 'Expédition internationale prioritaire des originaux papier dans le monde entier',
        },
      },
      summaryTitle: 'Récapitulatif du devis',
      perPageLabel: 'Tarif par page',
      translationSubtotal: 'Traduction assermentée',
      expressSurcharge: 'Majoration Express (12–24h)',
      deliveryLabel: 'Livraison & expédition',
      totalLabel: 'Total Estimé',
      clientSectionTitle: 'Vos Coordonnées',
      namePlaceholder: 'Nom complet *',
      emailPlaceholder: 'Adresse e-mail *',
      phonePlaceholder: 'Téléphone / WhatsApp (+212...) *',
      notesPlaceholder: 'Précisions (orthographe passeport, besoin d’Apostille...)',
      submitOrderBtn: 'Valider le Récapitulatif en Ligne',
      whatsappBtn: 'Envoyer sur WhatsApp',
      validationError: 'Veuillez renseigner votre nom complet, un e-mail valide et un numéro de téléphone.',
      receiptTitle: 'Récapitulatif de Commande Prêt',
      receiptSubtitle:
        'Votre référence de devis est générée. Transmettez-la par e-mail ou WhatsApp pour confirmation avec Maître Wahiba Bousmir.',
      receiptRefLabel: 'Référence',
      receiptSendEmail: 'Envoyer par E-mail (wbousmir@gmail.com)',
      receiptPrint: 'Imprimer / Enregistrer en PDF',
      receiptNewOrder: 'Nouveau Devis',
    },
    authorities: {
      kicker: 'Reconnaissance Officielle',
      title: 'Acceptée par les Juridictions, Ministères et Consulats',
      items: [
        { name: 'Tribunaux & Ministères du Maroc', detail: 'Cours d’Appel, Première Instance, Wilayas et Préfectures' },
        { name: 'États-Unis · USCIS', detail: 'Traductions certifiées avec attestation signée' },
        { name: 'Canada · IRCC & WES', detail: 'Entrée Express, permis d’études et évaluations' },
        { name: 'Royaume-Uni · Home Office', detail: 'Dossiers de visa, résidence et nationalité' },
        { name: 'Consulats UE & Schengen', detail: 'Centres de visa, regroupement familial et état civil' },
        { name: 'Prêt pour l’Apostille', detail: 'Mise en forme conforme Cour d’Appel & MAE' },
      ],
    },
    services: {
      kicker: 'Expertise Juridique & Académique',
      title: 'Nos Pôles de Traduction Assermentée',
      subtitle:
        'Chaque pièce est traduite, relue, cachetée et signée personnellement par Maître Wahiba Bousmir, sans sous-traitance.',
      selectAction: 'Configurer dans le devis',
      cards: [
        {
          id: 'civil',
          index: '01',
          title: 'Traductions Assermentées (Arabe ↔ Anglais)',
          description:
            'Exemplaires papier signés et cachetés accompagnés de scans numériques haute définition reconnus par les tribunaux, ambassades et universités.',
          examples: 'Actes d’état civil · Casier judiciaire · Passeports · Jugements',
        },
        {
          id: 'immigration',
          index: '02',
          title: 'Packs Immigration & Études à l’Étranger',
          description:
            'Prise en charge complète de vos dossiers de visa, admissions universitaires, équivalences de diplômes et regroupement familial.',
          examples: 'USCIS · IRCC · UKVI · Relevés de notes · Diplômes',
        },
        {
          id: 'legal',
          index: '03',
          title: 'Droit, Affaires & Assistance Apostille',
          description:
            'Traduction rigoureuse de contrats, statuts de sociétés et procurations, avec orientation étape par étape pour l’Apostille et la légalisation.',
          examples: 'Statuts · Procurations · Décisions judiciaires · Apostille',
        },
      ],
    },
    process: {
      kicker: 'Déroulement Transparent',
      title: 'De l’Envoi des Pièces au Cachet Officiel en 4 Étapes',
      steps: [
        {
          num: '01',
          title: 'Transmettez vos documents',
          desc: 'Déposez vos scans ou photos (PDF, JPG, PNG, DOCX) dans le calculateur ou directement sur WhatsApp.',
        },
        {
          num: '02',
          title: 'Confirmez la langue & la livraison',
          desc: 'Choisissez Arabe ↔ Anglais, l’autorité destinataire, le délai et le retrait au cabinet ou l’envoi.',
        },
        {
          num: '03',
          title: 'Traduction assermentée & contrôle',
          desc: 'Maître Wahiba Bousmir réalise la traduction avec vérification exacte des noms et termes juridiques.',
        },
        {
          num: '04',
          title: 'Recevez le PDF ou les originaux',
          desc: 'Réception immédiate du PDF certifié puis retrait à Tétouan ou expédition via Amana / DHL.',
        },
      ],
    },
    useCases: {
      kicker: 'Cas d’Usage & Garanties',
      title: 'Conçu pour Vos Démarches Décisives',
      subtitle:
        'Explorez les documents les plus demandés selon votre projet et les qualifications officielles qui garantissent leur validité.',
      cases: [
        {
          id: 'visas',
          title: 'Visas & Immigration',
          documents: 'Actes de naissance, casier judiciaire, relevés bancaires, attestations de travail',
          detail:
            'Préparation conforme aux normes USCIS, IRCC, UKVI et consulaires avec concordance stricte des passeports.',
          category: 'immigration',
        },
        {
          id: 'study',
          title: 'Études à l’Étranger',
          documents: 'Baccalauréat, relevés semestriels, diplômes, programmes de cours, lettres',
          detail:
            'Reconnus par les universités anglophones, organismes de bourses, WES et commissions d’équivalence.',
          category: 'academic',
        },
        {
          id: 'family',
          title: 'Mariage & État Civil Familial',
          documents: 'Actes de mariage adoulaires, certificats de célibat, livrets de famille, jugements',
          detail:
            'Maîtrise précise du droit de la famille marocain (Moudawana) prêt pour l’Apostille et la transcription.',
          category: 'civil',
        },
        {
          id: 'business',
          title: 'Entreprises & Contentieux',
          documents: 'Contrats, registres de commerce, procurations, sentences arbitrales, jugements',
          detail:
            'Confidentialité absolue et exactitude juridique assurées directement par une traductrice assermentée ATAJ.',
          category: 'corporate',
        },
      ],
      whyTitle: 'Les Engagements du Cabinet',
      whyPoints: [
        {
          title: 'Contact direct avec la traductrice — Sans intermédiaire',
          desc: 'Vous échangez directement avec Maître Wahiba Bousmir du devis jusqu’au sceau officiel, sans frais d’agence.',
        },
        {
          title: 'Rigueur de l’École Roi Fahd de Traduction',
          desc: 'Formation académique d’excellence garantissant une maîtrise terminologique juridique, diplomatique et financière.',
        },
        {
          title: 'Confidentialité sous serment judiciaire',
          desc: 'Vos pièces d’identité, dossiers familiaux et contrats d’affaires sont traités dans le secret professionnel le plus strict.',
        },
      ],
      credentialsCard: {
        schoolLabel: 'Diplôme Académique',
        schoolValue: "Diplômée de l'École Supérieure Roi Fahd de Traduction (Tanger)",
        atajLabel: 'Agrément Officiel',
        atajValue: 'Membre de l’ATAJ · Agréée par le Ministère de la Justice',
        pairLabel: 'Langues Assermentées',
        pairValue: 'Arabe ↔ Anglais (réseau partenaire Français & Espagnol)',
      },
    },
    office: {
      kicker: 'Cabinet à Tétouan & Contact Direct',
      title: 'Rendez-nous Visite près de la Cour d’Appel',
      subtitle:
        'Situé au Quartier Wilaya pour un dépôt rapide de vos pièces, le retrait des originaux cachetés et vos formalités d’Apostille.',
      addressLabel: 'Adresse du Cabinet',
      addressLatin:
        "Quartier Wilaya, Avenue Ali Yaâta, près de la Cour d'appel, Immeuble Jebli, entre-sol (bloc 9), Tétouan, Maroc",
      addressArabic:
        'حي الولاية، شارع علي يعتة، قرب محكمة الاستئناف، عمارة الجبلي، الطابق السفلي (البلوك 9)، تطوان',
      hoursLabel: 'Horaires d’ouverture',
      hoursValue: 'Lundi – Vendredi : 09h00 – 17h30 · Samedi : 09h30 – 13h00',
      phoneLabel: 'Téléphone & WhatsApp',
      emailLabel: 'E-mail Direct',
      landmarkTitle: 'Au Cœur du Pôle Judiciaire',
      landmarkDesc:
        'À deux minutes à pied de la Cour d’Appel de Tétouan — idéal pour enchaîner traduction assermentée et légalisation Apostille.',
      openMapsBtn: 'Itinéraire sur Google Maps',
      mapCourAppel: 'Cour d’Appel',
      mapCabinet: 'Cabinet W. Bousmir · Imm. Jebli (Bloc 9)',
      mapAvenue: 'Avenue Ali Yaâta',
      mapWilaya: 'Quartier Wilaya',
    },
    footer: {
      copyright: '© 2026 Cabinet Maître Wahiba Bousmir. Tous droits réservés.',
      tagline: 'Traductrice Assermentée près les Juridictions & Consulats · Arabe ↔ Anglais',
      quickLinks: 'Navigation',
      credentialsTitle: 'Accréditations Officielles',
    },
    whatsappFloat: 'WhatsApp : 06 90 12 97 97',
  },
  ar: {
    brand: {
      name: 'الأستاذة وهيبة بوسمير',
      arabicName: 'Maître Wahiba Bousmir',
      title: 'ترجمانة محلفة مقبولة لدى المحاكم والقنصليات',
      shortTitle: 'ترجمانة محلفة · عربية ↔ إنجليزية',
      school: 'خريجة مدرسة الملك فهد العليا للترجمة',
      accreditation: 'عضو بالهيئة الوطنية للتراجمة المحلفين (التاج) المعتمدة من لدن وزارة العدل',
      pair: 'عربية ↔ إنجليزية',
      partnerNote: 'دعم متاح عبر شبكة الشركاء المحلفين للغتين الفرنسية والإسبانية.',
    },
    nav: {
      services: 'الخدمات',
      authorities: 'الجهات المعتمدة',
      howItWorks: 'خطوات الطلب',
      credentials: 'الاعتماد الرسمي',
      office: 'المكتب والتواصل',
      cta: 'احسب السعر واطلب',
    },
    hero: {
      kicker: 'معتمدة من لدن وزارة العدل · عضو بالهيئة الوطنية للتراجمة المحلفين (التاج)',
      headline: 'ترجمة محلفة عربية ↔ إنجليزية معتمدة دولياً لدى المحاكم والقنصليات',
      subtitle:
        'ترجمات رسمية مختومة وموقعة من طرف الأستاذة وهيبة بوسمير، خريجة مدرسة الملك فهد العليا للترجمة. تسليم رقمي سريع وشحن دولي موثوق انطلاقاً من تطوان.',
      highlights: [
        'إنجاز سريع خلال 12 إلى 24 ساعة',
        'مقبولة لدى السفارات، القنصليات، USCIS، IRCC والمحاكم',
        'إرشاد ومواكبة لإجراءات الأبوستيل والمصادقة',
        'طلب مباشر عبر الموقع أو الواتساب',
      ],
      primaryCta: 'اطلب ترجمتك الآن',
      secondaryCta: 'تواصل عبر الواتساب (97 97 12 90 06)',
      stripItems: [
        'عضو هيئة التاج (ATAJ)',
        'معتمدة لدى وزارة العدل',
        'خريجة مدرسة الملك فهد للترجمة',
        'دائرة محكمة الاستئناف بتطوان',
      ],
      certToggle: {
        sworn: 'نموذج الترجمة المحلفة',
        apostille: 'صيغة الأبوستيل',
      },
      certDoc: {
        headerTop: 'المملكة المغربية · محكمة الاستئناف بتطوان',
        headerSub: 'مكتب الأستاذة وهيبة بوسمير · ترجمانة محلفة',
        title: 'ترجمة رسمية محلفة ومعتمدة',
        apostilleTitle: 'جاهزية الأبوستيل والمصادقة القنصلية',
        bodySnippet:
          'أنا الموقعة أسفله، الأستاذة وهيبة بوسمير، ترجمانة محلفة مقبولة لدى محاكم المملكة المغربية (عربية ↔ إنجليزية)، أشهد بأن الترجمة المرفقة مطابقة تمام المطابقة للأصل المقدم إليّ.',
        apostilleSnippet:
          'معدة وفق متطلبات اتفاقية لاهاي (الأبوستيل) ومصادقات وزارة الشؤون الخارجية، ومقبولة لدى مصالح الهجرة الأمريكية USCIS والكندية IRCC والبريطانية وسفارات شنغن.',
        attestation: 'موقعة ومختومة ومسجلة بتطوان',
        sealLabel: 'ترجمانة محلفة · التاج',
        regNo: 'مرجع WB-AR/EN-2026',
        locationLine: 'شارع علي يعتة، عمارة الجبلي · تطوان',
      },
    },
    calculator: {
      sectionKicker: 'حاسبة الأسعار ورفع الوثائق',
      sectionTitle: 'احصل على تسعيرة فورية وأرسل وثائقك',
      sectionSubtitle:
        'حدد تفاصيل الترجمة المحلفة لمعرفة التكلفة التقديرية بشفافية وإرسال ملفاتك مباشرة إلى مكتب الأستاذة وهيبة بوسمير.',
      stepDirection: '1. اتجاه الترجمة',
      directions: {
        'ar-en': 'من العربية إلى الإنجليزية',
        'en-ar': 'من الإنجليزية إلى العربية',
      },
      partnerHint:
        'هل تحتاج للترجمة بالفرنسية أو الإسبانية؟ أشر إلى ذلك في الملاحظات للتنسيق مع شبكتنا المعتمدة.',
      stepCategory: '2. نوع الوثيقة',
      categories: {
        civil: {
          label: 'الحالة المدنية',
          desc: 'عقود الازدياد، الزواج، الطلاق، السجل العدلي، الدفتر العائلي',
        },
        academic: {
          label: 'الشهادات والدراسة',
          desc: 'الدبلومات، كشوف النقط، شواهد التسجيل، ملفات المعادلة',
        },
        legal: {
          label: 'الوثائق القانونية والقضائية',
          desc: 'الأحكام القضائية، العقود العدلية، التوثيق، الوكالات',
        },
        corporate: {
          label: 'الشركات والعقود التجارية',
          desc: 'الأنظمة الأساسية، العقود التجارية، السجل التجاري، التقارير المالية',
        },
        immigration: {
          label: 'ملفات الهجرة والتأشيرة',
          desc: 'ملفات USCIS، IRCC، التأشيرة البريطانية وشنغن والتجمع العائلي',
        },
      },
      stepDestination: '3. البلد أو الجهة المستقبلة',
      destinations: {
        morocco: 'المغرب (المحاكم / الوزارات)',
        usa: 'الولايات المتحدة (USCIS)',
        canada: 'كندا (IRCC / WES)',
        uk: 'المملكة المتحدة (Home Office)',
        eu: 'الاتحاد الأوروبي / السفارات والقنصليات',
      },
      stepSpeed: '4. سرعة الإنجاز',
      speeds: {
        standard: { label: 'عادي', time: '24–48 ساعة' },
        express: { label: 'مستعجل', time: '12–24 ساعة' },
      },
      stepPages: '5. عدد الصفحات التقديري',
      pagesUnit: 'صفحات',
      stepUpload: '6. إرفاق الوثائق للمعاينة (اختياري)',
      dropzoneTitle: 'اسحب الملفات وأفلتها هنا، أو انقر للاختيار',
      dropzoneSub: 'تبقى ملفاتك خاصة داخل متصفحك للمعاينة وتحديد تفاصيل الطلب.',
      dropzoneFormats: 'الصيغ المدعومة: PDF, JPG, PNG, DOCX',
      removeFile: 'حذف',
      stepDelivery: '7. طريقة التسليم والشحن',
      deliveries: {
        pickup: {
          label: 'نسخة PDF مصادق عليها + استلام من المكتب (تطوان)',
          desc: 'نسخة رقمية مختومة عبر البريد أو الواتساب + الأصل من عمارة الجبلي قرب محكمة الاستئناف',
        },
        amana: {
          label: 'نسخة PDF + إرسال عبر أمانة (داخل المغرب)',
          desc: 'توصيل مضمون للنسخ الأصلية المختومة إلى كافة المدن المغربية',
        },
        dhl: {
          label: 'نسخة PDF + شحن دولي سريع عبر DHL',
          desc: 'شحن دولي مستعجل للوثائق الورقية المختومة إلى جميع أنحاء العالم',
        },
      },
      summaryTitle: 'ملخص الطلب والتسعيرة',
      perPageLabel: 'التعريفة لكل صفحة',
      translationSubtotal: 'تكلفة الترجمة المحلفة',
      expressSurcharge: 'رسوم الاستعجال (12–24 ساعة)',
      deliveryLabel: 'التسليم والشحن',
      totalLabel: 'المجموع التقديري',
      clientSectionTitle: 'معلومات التواصل الخاصة بك',
      namePlaceholder: 'الاسم الكامل *',
      emailPlaceholder: 'البريد الإلكتروني *',
      phonePlaceholder: 'رقم الهاتف أو الواتساب (+212...) *',
      notesPlaceholder: 'ملاحظات إضافية (تهجئة الاسم في جواز السفر، الحاجة للأبوستيل...)',
      submitOrderBtn: 'تأكيد ملخص الطلب عبر الموقع',
      whatsappBtn: 'إرسال الطلب عبر واتساب',
      validationError: 'يرجى إدخال الاسم الكامل وبريد إلكتروني صحيح ورقم الهاتف.',
      receiptTitle: 'تم إعداد ملخص طلبك بنجاح',
      receiptSubtitle:
        'المرجع الخاص بطلبك جاهز. يمكنك إرساله عبر البريد الإلكتروني أو الواتساب للتأكيد النهائي مع الأستاذة وهيبة بوسمير.',
      receiptRefLabel: 'رقم المرجع',
      receiptSendEmail: 'إرسال عبر البريد (wbousmir@gmail.com)',
      receiptPrint: 'طباعة / حفظ الملخص PDF',
      receiptNewOrder: 'حساب طلب جديد',
    },
    authorities: {
      kicker: 'الاعتماد والقبول الرسمي',
      title: 'ترجمات مقبولة لدى المحاكم والوزارات والقنصليات',
      items: [
        { name: 'المحاكم والوزارات المغربية', detail: 'محاكم الاستئناف، الابتدائية، الولايات والعمالات' },
        { name: 'أمريكا · USCIS', detail: 'ترجمات مصادق عليها مع شهادة المطابقة الموقعة' },
        { name: 'كندا · IRCC و WES', detail: 'ملفات الهجرة، الدراسة ومعادلة الشهادات' },
        { name: 'بريطانيا · Home Office', detail: 'ملفات التأشيرة والإقامة والجنسية' },
        { name: 'سفارات الاتحاد الأوروبي وشنغن', detail: 'طلبات التأشيرة، التجمع العائلي والحالة المدنية' },
        { name: 'جاهزة للأبوستيل (Apostille)', detail: 'تنسيق مطابق لمساطر محكمة الاستئناف والخارجية' },
      ],
    },
    services: {
      kicker: 'خدمات قانونية وأكاديمية متخصصة',
      title: 'خدمات الترجمة المحلفة الأساسية',
      subtitle:
        'تُنجز كل ترجمة وتُراجع وتُختم شخصياً من لدن الأستاذة وهيبة بوسمير دون أي وساطة تجارية.',
      selectAction: 'اختر في حاسبة التسعيرة',
      cards: [
        {
          id: 'civil',
          index: '01',
          title: 'الترجمة المحلفة (عربية ↔ إنجليزية)',
          description:
            'نسخ ورقية رسمية مختومة وموقعة مرفقة بنسخ رقمية عالية الجودة مقبولة لدى المحاكم والسفارات والجامعات.',
          examples: 'عقود الازدياد والزواج · السجل العدلي · جوازات السفر · الأحكام',
        },
        {
          id: 'immigration',
          index: '02',
          title: 'باقات الهجرة والدراسة بالخارج',
          description:
            'ترجمة متكاملة لملفات التأشيرات، القبول الجامعي، معادلة الشهادات، وملفات التجمع العائلي.',
          examples: 'USCIS · IRCC · التأشيرات · كشوف النقط · الدبلومات',
        },
        {
          id: 'legal',
          index: '03',
          title: 'العقود التجارية والقانونية والأبوستيل',
          description:
            'ترجمة دقيقة للعقود والأنظمة الأساسية للشركات والوكالات، مع إرشاد عملي لمساطر الأبوستيل والمصادقة.',
          examples: 'القانون الأساسي · الوكالات · الأحكام القضائية · الأبوستيل',
        },
      ],
    },
    process: {
      kicker: 'خطوات واضحة وسريعة',
      title: 'من إرسال الوثيقة إلى الختم الرسمي في 4 خطوات',
      steps: [
        {
          num: '01',
          title: 'أرسل وثائقك',
          desc: 'قم برفع صور أو ملفات PDF في الحاسبة أو أرسلها مباشرة عبر تطبيق واتساب.',
        },
        {
          num: '02',
          title: 'أكد اللغة وطريقة التسليم',
          desc: 'اختر اتجاه الترجمة (عربية ↔ إنجليزية)، الجهة المستقبلة، سرعة الإنجاز وطريقة الاستلام.',
        },
        {
          num: '03',
          title: 'الترجمة المحلفة والمراجعة',
          desc: 'تتولى الأستاذة وهيبة بوسمير الترجمة ومطابقة الأسماء مع جواز السفر والمصطلحات القانونية.',
        },
        {
          num: '04',
          title: 'استلم النسخة الرقمية والأصلية',
          desc: 'احصل على النسخة الرقمية المختومة فوراً مع إمكانية الاستلام من مكتب تطوان أو عبر أمانة وDHL.',
        },
      ],
    },
    useCases: {
      kicker: 'حلول عملية وبيانات الاعتماد',
      title: 'ترجمة دقيقة لمختلف الملفات القانونية والأكاديمية',
      subtitle:
        'اختر نوع ملفك للاطلاع على الوثائق المطلوبة، وتعرف على المؤهلات الرسمية التي تضمن قبول ترجمتك.',
      cases: [
        {
          id: 'visas',
          title: 'التأشيرات والهجرة',
          documents: 'عقود الازدياد، السجل العدلي، كشوف الحساب البنكي، شواهد العمل وعقود الزواج',
          detail:
            'تُعد وفق شروط مصالح الهجرة الأمريكية والكندية والبريطانية والقنصليات مع مطابقة تامة لتهجئة الجواز.',
          category: 'immigration',
        },
        {
          id: 'study',
          title: 'الدراسة بالخارج والمعادلة',
          documents: 'شهادة البكالوريا، كشوف النقط الجامعية، الدبلومات، التوصيف الدراسي',
          detail:
            'مقبولة لدى الجامعات الدولية، لجان المنح الدراسية، منظمة WES، ومصالح معادلة الشهادات.',
          category: 'academic',
        },
        {
          id: 'family',
          title: 'الزواج ووثائق الأسرة',
          documents: 'عقود الزواج العدلية، شواهد العزوبة، الدفتر العائلي، أحكام التطليق والحضانة',
          detail:
            'نقل دقيق لمصطلحات مدونة الأسرة المغربية بما يتناسب مع متطلبات الأبوستيل والتسجيل القنصلي.',
          category: 'civil',
        },
        {
          id: 'business',
          title: 'الشركات والمنازعات القضائية',
          documents: 'العقود التجارية، السجل التجاري، الوكالات، المقررات التحكيمية والأحكام القضائية',
          detail:
            'سرية تامة وصياغة قانونية محكمة تنجز مباشرة على يد ترجمانة محلفة مسجلة بهيئة التاج.',
          category: 'corporate',
        },
      ],
      whyTitle: 'لماذا تختار التعامل المباشر مع مكتبنا؟',
      whyPoints: [
        {
          title: 'تعامل مباشر مع الترجمانة المحلفة دون وسطاء',
          desc: 'تتواصل مباشرة مع الأستاذة وهيبة بوسمير من لحظة طلب التسعيرة حتى استلام الوثيقة المختومة.',
        },
        {
          title: 'تكوين أكاديمي رفيع بمدرسة الملك فهد للترجمة',
          desc: 'تأهيل متخصص من أعرق مؤسسة لتكوين التراجمة بالمغرب لضمان الدقة القانونية واللغوية.',
        },
        {
          title: 'سرية تامة والتزام بأخلاقيات القسم القانوني',
          desc: 'حفظ كامل لخصوصية الوثائق الشخصية، الملفات الأسرية، والعقود التجارية الحساسة.',
        },
      ],
      credentialsCard: {
        schoolLabel: 'الشهادة الأكاديمية',
        schoolValue: 'خريجة مدرسة الملك فهد العليا للترجمة (طنجة)',
        atajLabel: 'الاعتماد المهني',
        atajValue: 'عضو بالهيئة الوطنية للتراجمة المحلفين (التاج) المعتمدة من لدن وزارة العدل',
        pairLabel: 'الاختصاص المحلف الأساسي',
        pairValue: 'عربية ↔ إنجليزية (مع دعم شبكة الشركاء للفرنسية والإسبانية)',
      },
    },
    office: {
      kicker: 'مكتب تطوان والتواصل المباشر',
      title: 'تفضلوا بزيارة المكتب قرب محكمة الاستئناف',
      subtitle:
        'موقع مركزي بحي الولاية يسهل عليكم تسليم الوثائق واستلام النسخ الأصلية المختومة وإتمام إجراءات الأبوستيل.',
      addressLabel: 'عنوان المكتب',
      addressLatin:
        "Quartier Wilaya, Avenue Ali Yaâta, près de la Cour d'appel, Immeuble Jebli, entre-sol (bloc 9), Tétouan",
      addressArabic:
        'حي الولاية، شارع علي يعتة، قرب محكمة الاستئناف، عمارة الجبلي، الطابق السفلي (البلوك 9)، تطوان',
      hoursLabel: 'أوقات العمل',
      hoursValue: 'الإثنين – الجمعة: 09:00 – 17:30 · السبت: 09:30 – 13:00',
      phoneLabel: 'الهاتف والواتساب',
      emailLabel: 'البريد الإلكتروني',
      landmarkTitle: 'موقع استراتيجي بالمنطقة القضائية',
      landmarkDesc:
        'على بُعد دقيقتين مشياً من محكمة الاستئناف بتطوان — موقع مثالي عند الحاجة للمصادقة والأبوستيل بعد استلام الترجمة.',
      openMapsBtn: 'عرض الموقع على خرائط Google',
      mapCourAppel: 'محكمة الاستئناف',
      mapCabinet: 'مكتب الأستاذة وهيبة بوسمير · عمارة الجبلي (البلوك 9)',
      mapAvenue: 'شارع علي يعتة',
      mapWilaya: 'حي الولاية',
    },
    footer: {
      copyright: '© 2026 مكتب الأستاذة وهيبة بوسمير للترجمة المحلفة. جميع الحقوق محفوظة.',
      tagline: 'ترجمانة محلفة مقبولة لدى المحاكم والقنصليات · عربية ↔ إنجليزية',
      quickLinks: 'روابط سريعة',
      credentialsTitle: 'الاعتماد الرسمي',
    },
    whatsappFloat: 'واتساب: 97 97 12 90 06',
  },
};
