import { useEffect, useState } from 'react';
import { Currency, DocumentCategory, Language } from './types/translation';
import { DICTIONARY } from './data/translations';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { QuoteCalculator } from './components/QuoteCalculator';
import { ServicesAndProcess } from './components/ServicesAndProcess';
import { UseCasesAndCabinet } from './components/UseCasesAndCabinet';
import { OfficeAndFooter } from './components/OfficeAndFooter';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [currency, setCurrency] = useState<Currency>('MAD');
  const [selectedCategory, setSelectedCategory] = useState<DocumentCategory>('civil');

  const t = DICTIONARY[lang];

  // Live RTL/LTR direction and document lang synchronization
  useEffect(() => {
    const html = document.documentElement;
    html.lang = lang;
    html.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const scrollToCalculator = () => {
    const el = document.getElementById('calculator');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectCategory = (cat: DocumentCategory) => {
    setSelectedCategory(cat);
    scrollToCalculator();
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#1E1A1D]">
      <Navbar
        lang={lang}
        setLang={setLang}
        currency={currency}
        setCurrency={setCurrency}
        t={t}
        onJumpToCalculator={scrollToCalculator}
      />

      <main className="flex-1">
        <HeroSection
          lang={lang}
          t={t}
          onJumpToCalculator={scrollToCalculator}
        />

        <QuoteCalculator
          lang={lang}
          currency={currency}
          t={t}
          category={selectedCategory}
          setCategory={setSelectedCategory}
        />

        <ServicesAndProcess
          lang={lang}
          t={t}
          onSelectCategory={handleSelectCategory}
        />

        <UseCasesAndCabinet
          lang={lang}
          t={t}
          onSelectCategory={handleSelectCategory}
        />
      </main>

      <OfficeAndFooter lang={lang} t={t} />
    </div>
  );
}
